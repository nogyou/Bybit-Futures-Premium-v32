# BYBIT FUTURES PREMIUM v3.3.0 — Arena-style Decision Journal (Phase 1 / Beta)

이번 버전은 기존 **v3.2.9**에서 발전시킨 **Alpha Arena 공개 사례의 설계 방식 참고 버전**입니다. 대회 참여 모델의 내부 가중치·비공개 프롬프트·실제 GPT-6 매매 전략을 복제한 제품이 **아닙니다**. GPT 모델/API는 **아직 앱에 연결되지 않았습니다**.

## 이번에 실제 구현한 것

1. **근거가 보이는 LONG·SHORT·WAIT 리뷰**: 선택한 단타(5분)·단기(30분)·장기(일봉) 모드에서 양방향 지표 부합률(승률 아님), TP1의 비용 후 손익비, WAIT 사유, 다음 확인 조건을 표시합니다. 기존 EMA·RSI·MACD·ATR·지지저항·피보나치·OI·펀딩비 분석 및 위험 판정 기능은 유지했습니다.
2. **진입 판단 기록**: 현재 선택 종목의 세 모드에 대해 실제 분석 시점을 로컬에 기록합니다. 같은 완성봉 안에서 같은 WAIT/LONG/SHORT가 반복 호출되어도 기록을 중복 추가하지 않습니다. 이벤트별 시점, 가격, LONG/SHORT 지표 점수, 예상 TP1/SL, WAIT 유형, 배율·수수료 가정을 저장합니다.
3. **화면이 열려 있을 때만 작동하는 전방 모의 추적**: 신선한 데이터, 위험 조건 통과 후 WAIT 등에서 실제 조건부 LONG/SHORT가 새로 발생하면 `PENDING` 상태로 등록합니다. **그다음 관측한 시세**에 편도 슬리피지 가정을 적용한 가격으로 모의 진입합니다. 이후 **관측한** 가격이 TP1/SL을 통과하면, 해당 관측 시세로 모의 청산·수수료·ROI·USDT 순손익을 추정합니다. Bybit 실제 주문은 없으며 **시뮬레이션 체결이지 실제 체결이 아닙니다**.
4. **정직한 미검증 처리**: 앱 백그라운드 전환·재시작·시세 공백·관측시간 초과 시에는 그 사이 TP/SL 여부를 추측하지 않고 `UNVERIFIED` 또는 `EXPIRED`로 기록합니다. 이를 성과 통계의 승패에서 제외합니다.
5. **성과 보기**: 단타/단기/장기의 WAIT 기록·TP1/SL 결과·가상 순손익·최대 가상 누적손실폭과 주요 WAIT 원인을 비교합니다. 관측 이벤트 개수와 거래 표본이 극히 적으면 결과가 대표성 없음을 명시합니다.
6. **AI 입력 데이터 패킷 JSON**: 차트 지표, 양방향 후보, 다중 시간봉, 최근 **완성봉** 24개, 데이터 신선도, 거래 비용을 일관된 구조로 확인할 수 있습니다. **모델 전송·매매 추천 재판정은 아직 없습니다.** 향후 보안 서버 연결의 바탕입니다.
7. 차트의 **작은 현재가 가격표/가로 실선, 손가락 가로 탐색선, 진입·익절 가격대 표시**와 기존 화면의 캔들 수/크기는 변경하지 않았습니다.

## 설치 / GitHub Actions APK

1. 기존 개인 Codespace `Bybit-Futures-Premium-v32`를 연 뒤 다운로드한 소스 ZIP 자체를 프로젝트 최상위 폴더에 업로드합니다.
2. PC Codespaces 터미널에 아래를 실행합니다.

```bash
unzip -o Bybit-Futures-Premium-v3.3.0-Arena-Journal-Source.zip
git status --short
git add app tests docs .github README.md build.gradle.kts settings.gradle.kts gradle.properties
git commit -m "Upgrade to Bybit Premium v3.3.0 Arena Journal"
git push origin main
```

3. GitHub 저장소 **Actions** → 가장 최근 `Build Bybit Futures v3.3.0 APK` 성공 항목 → **Artifacts**에서 `Bybit-v330-Arena-Journal-debug-APK`를 내려받고 압축을 풀어 `app-debug.apk`를 설치합니다.
4. 설치 전 이름은 `Bybit Trade Terminal 3.3.0`, 앱 ID는 `com.bybit.tradeterminal.v330`, 내부 버전 `3.3.0-arena-journal-beta`입니다. 이전 3.2.x와 **별도 앱으로 설치**되며, 이전 앱의 사용자 설정/성과 기록을 자동으로 이전하지 않습니다.

### 주의

- **앱을 켜 둔 시간 + 실제로 본 종목**에 대한 부분 관측 실험입니다. 역사적 전체 거래 데이터 백테스트나 24시간 운영 모니터링이 아닙니다.
- 종목을 변경하거나 앱을 닫으면 미추적 거래를 미검증 처리하므로 표본이 제한됩니다. 신호가 계속 WAIT여도 결과가 조작되지 않도록 그대로 기록합니다.
- **실제 수익/승률 검증 불가**: 실시간 last trade 가격으로 다음 틱 가상 체결을 추정하며 실제 호가 스프레드·체결량·펀딩·시장 충격·강제청산·거래소 주문 속도는 반영하지 못합니다. 수수료/슬리피지는 사용자가 설정한 추정값입니다.
- 가격 도달만으로 진입할 수 없으며 **기존 조건부 LONG/SHORT 엔진 규칙은 유지**했습니다. 신호 빈도가 늘어났다고 주장하지 않습니다.
- 앱 데이터는 `localStorage`에 최대 900개 결정/350개 가상 추적 기록으로 제한됩니다. 앱 삭제/앱 데이터 삭제/새 앱 ID 설치 시 기록이 사라질 수 있습니다. 성과창에서 JSON을 선택 복사해 별도 백업하십시오.
- 한 거래가 진행 중일 때 종목별·모드별 추가 가상 주문은 중복 기록하지 않습니다. 앱이 자동으로 실제 Bybit 포지션을 읽거나 주문하지 않습니다. API 키를 안드로이드에 저장하거나 공유하지 마세요.
- Node 단위 테스트 및 브라우저 UI 스모크 테스트는 수행했지만 **Android GitHub Actions APK 빌드와 Lenovo Y700 실기기 동작은 아직 미검증**입니다.

## 다음 개발 단계

`docs/AI_GATEWAY_PLAN.md`에 GPT 연결 계획을 기록했습니다. 서버에서만 모델 API 키를 보호하고 모델에게 **WAIT/LONG/SHORT, 가격, 손익비, 이유 및 위험 근거**를 구조화된 응답으로 받되, 최종 지표·위험 필터를 우회하지 않도록 검증해야 합니다. 모델을 연결한 뒤 동일 시장 시점의 3.2.8 / 3.2.9 / 3.3 모델 간 워크포워드 평가를 수행하는 것이 다음 목표입니다.

참고: https://alpha-arena.io/leaderboard , https://developers.openai.com/api/docs/guides/structured-outputs
