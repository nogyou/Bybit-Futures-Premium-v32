/* BYBIT FUTURES PREMIUM 3.3 — transparent forward-only signal journal.
 * Inspired by the public Alpha Arena benchmark's evidence -> decision -> ledger -> evaluation workflow.
 * NOT an Alpha Arena model, not an OpenAI API integration, not an exchange execution engine.
 * Local-only data; no retroactive fills, no inferred fills during a disconnect.
 */
'use strict';
const DecisionLab = (()=>{
  const VERSION=1, STORAGE='v330-forward-journal-v1', MAX_DECISIONS=900, MAX_TRADES=350;
  const modes=['scalp','short','long'];
  const safeNum=(v,fallback=NaN)=>(v===null||v===undefined||v==='')?fallback:(Number.isFinite(Number(v))?Number(v):fallback);
  const isSide=v=>v==='LONG'||v==='SHORT';
  const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
  const cleanSymbol=s=>String(s||'').replace(/[^A-Z0-9]/g,'').slice(0,25);
  function makeStorage(storage){return storage||{getItem:()=>null,setItem:()=>{}};}
  function empty(){return {v:VERSION,decisions:[],trades:[],lastVerdicts:{},sequence:0};}
  function create(storage,clock=()=>Date.now()){
    storage=makeStorage(storage);let data=empty();let enabled=true;
    try{const raw=JSON.parse(storage.getItem(STORAGE)||'null');if(raw&&raw.v===VERSION&&Array.isArray(raw.decisions)&&Array.isArray(raw.trades)){
      data={...empty(),...raw,decisions:raw.decisions.slice(-MAX_DECISIONS),trades:raw.trades.slice(-MAX_TRADES),lastVerdicts:raw.lastVerdicts||{}};
    }}catch(_){/* private browser mode */}
    // No chart history / live tick history is available across app restarts. Do not claim those
    // positions hit TP/SL while the app was closed. Incomplete trials are not counted as wins/losses.
    let interrupted=false;
    for(const t of data.trades){if(t.status==='OPEN'||t.status==='PENDING'){
      t.status='UNVERIFIED';t.outcome='APP_RESTART';t.closedAt=clock();interrupted=true;
    }}
    if(interrupted)persist();
    function persist(){try{storage.setItem(STORAGE,JSON.stringify(data));}catch(_){/* memory-only mode; never fabricate persistence */}}
    function summary(mode=null){
      const ds=data.decisions.filter(x=>!mode||x.mode===mode);
      const ts=data.trades.filter(x=>!mode||x.mode===mode);
      const closed=ts.filter(x=>x.status==='TP1'||x.status==='SL');
      const wins=closed.filter(x=>x.status==='TP1').length;
      const waits=ds.filter(x=>x.verdict==='WAIT');
      const reasonCounts={};for(const d of waits){const key=d.waitKind||'CONFIRMATION';reasonCounts[key]=(reasonCounts[key]||0)+1;}
      const pnl=closed.reduce((s,x)=>s+x.netPnl,0);
      let equity=0,peak=0,maxDrawdownUsdt=0;
      for(const t of closed.slice().sort((a,b)=>a.closedAt-b.closedAt)){
        equity+=t.netPnl;peak=Math.max(peak,equity);maxDrawdownUsdt=Math.max(maxDrawdownUsdt,peak-equity);
      }
      return {decisions:ds.length,waits:waits.length,waitShare:ds.length?waits.length/ds.length:null,
        entries:ts.length,open:ts.filter(x=>x.status==='OPEN').length,pending:ts.filter(x=>x.status==='PENDING').length,
        unverified:ts.filter(x=>x.status==='UNVERIFIED'||x.status==='EXPIRED').length,
        closed:closed.length,wins,losses:closed.length-wins,winRate:closed.length?wins/closed.length:null,
        netPnl:pnl,avgPnl:closed.length?pnl/closed.length:null,maxDrawdownUsdt,
        waitReasons:reasonCounts, trades:ts, recent:ds.slice(-30).reverse()};
    }
    function record(snapshot){
      if(!snapshot||!modes.includes(snapshot.mode)||!cleanSymbol(snapshot.symbol))return {added:false};
      const at=safeNum(snapshot.at,clock()),barTime=safeNum(snapshot.closedBarTime,0);
      const rawVerdict=isSide(snapshot.verdict)?snapshot.verdict:'WAIT';
      const riskReason=String(snapshot.riskReason||'');
      const verdict=(snapshot.stale||riskReason)?'WAIT':rawVerdict;
      const a=snapshot.analysis||{},long=a.long||{},short=a.short||{};
      const active=verdict==='LONG'?long:verdict==='SHORT'?short:null;
      const preferred=[long,short].filter(p=>Number.isFinite(p.rr)).sort((x,y)=>y.rr-x.rr)[0];
      const waitKind=snapshot.stale?'STALE':riskReason?'ACCOUNT_RISK':preferred?.waitKind||'CONFIRMATION';
      const key=cleanSymbol(snapshot.symbol)+'|'+snapshot.mode;
      const id=key+'|'+barTime+'|'+verdict;
      // Sampling unit: one outcome per completed anchor candle AND distinct signal state.
      // Repeated streaming ticks of a still-forming candle cannot inflate WAIT statistics.
      if(data.decisions.some(d=>d.id===id))return {added:false};
      const d={id,at,barTime,symbol:cleanSymbol(snapshot.symbol),mode:snapshot.mode,verdict,
        rawVerdict,waitKind,reason:(snapshot.stale?'시장 데이터 지연':riskReason||a.vreason||'' ).slice(0,200),
        longScore:safeNum(long.score,null),shortScore:safeNum(short.score,null),
        longRr:safeNum(long.rr,null),shortRr:safeNum(short.rr,null),
        entry:isSide(verdict)?safeNum(active.entry,null):null,
        tp1:isSide(verdict)?safeNum(active.tp1,null):null,sl:isSide(verdict)?safeNum(active.stop,null):null,
        marketPrice:safeNum(snapshot.price,null),leverage:clamp(safeNum(snapshot.leverage,1),1,100),
        margin:clamp(safeNum(snapshot.margin,100),1,100000),
        fee:clamp(safeNum(snapshot.fee,.0006),0,.01),slip:clamp(safeNum(snapshot.slip,.00025),0,.01),
        dataQuality:snapshot.stale?'STALE':riskReason?'RISK_BLOCK':'FRESH'};
      const previous=data.lastVerdicts[key]||'WAIT';
      data.lastVerdicts[key]=verdict;data.decisions.push(d);data.decisions=data.decisions.slice(-MAX_DECISIONS);
      let queued=false;
      if(enabled&&isSide(verdict)&&previous!==verdict&&active&&
          Number.isFinite(d.tp1)&&Number.isFinite(d.sl)&&d.tp1>0&&d.sl>0&&d.marketPrice>0){
        const existing=data.trades.some(t=>t.symbol===d.symbol&&t.mode===d.mode&&(t.status==='OPEN'||t.status==='PENDING'));
        const direction=verdict==='LONG'?1:-1;
        const structure=(d.tp1-d.marketPrice)*direction>0&&(d.sl-d.marketPrice)*direction<0;
        if(!existing&&structure){
          data.sequence+=1;
          data.trades.push({id:'P'+data.sequence+'-'+at,symbol:d.symbol,mode:d.mode,side:verdict,
            signalAt:at,openedAt:null,closedAt:null,status:'PENDING',signalPrice:d.marketPrice,
            entry:null,tp1:d.tp1,sl:d.sl,margin:d.margin,leverage:d.leverage,fee:d.fee,slip:d.slip,
            netPnl:null,netRoi:null,outcome:null,lastQuoteAt:at,sourceDecisionId:id});
          data.trades=data.trades.slice(-MAX_TRADES);queued=true;
        }
      }
      persist();return {added:true,decision:d,queued};
    }
    function onQuote(symbol,price,at=clock()){
      if(!enabled)return {updated:0};symbol=cleanSymbol(symbol);price=safeNum(price);at=safeNum(at);
      if(!symbol||!Number.isFinite(price)||price<=0||!Number.isFinite(at))return {updated:0};
      let updated=0;
      for(const t of data.trades){if(t.symbol!==symbol||!['OPEN','PENDING'].includes(t.status))continue;
        if(at<=t.lastQuoteAt)continue;
        if(at-t.lastQuoteAt>120000){t.status='UNVERIFIED';t.outcome='DATA_GAP';t.closedAt=at;updated++;continue;}
        if(t.status==='PENDING'){
          if(at-t.signalAt>60000){t.status='EXPIRED';t.outcome='NO_NEXT_QUOTE';t.closedAt=at;updated++;continue;}
          const dir=t.side==='LONG'?1:-1,fill=price*(1+dir*t.slip);
          // A signal is not a transaction. The next observed tick is an *indicative*
          // hypothetical entry; if price already moved beyond TP/SL there is no fill.
          if((t.tp1-fill)*dir<=0||(t.sl-fill)*dir>=0){t.status='EXPIRED';t.outcome='BAD_NEXT_PRICE';t.closedAt=at;updated++;continue;}
          t.entry=fill;t.status='OPEN';t.openedAt=at;t.lastQuoteAt=at;updated++;continue;
        }
        const dir=t.side==='LONG'?1:-1;
        const atStop=dir*(price-t.sl)<=0,atTarget=dir*(price-t.tp1)>=0;
        const age=at-t.openedAt;
        const maxAge=t.mode==='scalp'?3600000:t.mode==='short'?172800000:1814400000;
        if(atStop||atTarget){
          t.status=atStop?'SL':'TP1';t.outcome=t.status;t.closedAt=at;
          // Market-price last traded, slippage both sides, and two taker-like fee estimates.
          const exit=price*(1-dir*t.slip);
          const gross=dir*(exit-t.entry)/t.entry;
          const net=gross-2*t.fee;
          t.exit=exit;t.netPnl=net*t.margin*t.leverage;t.netRoi=net*t.leverage*100;
          updated++;
        }else if(age>maxAge){t.status='UNVERIFIED';t.outcome='HORIZON_EXPIRED';t.closedAt=at;updated++;}
        else t.lastQuoteAt=at;
      }
      if(updated)persist();return {updated};
    }
    function markInterrupted(reason='APP_HIDDEN'){
      let n=0;for(const t of data.trades)if(t.status==='OPEN'||t.status==='PENDING'){
        t.status='UNVERIFIED';t.outcome=reason;t.closedAt=clock();n++;
      }
      if(n){data.lastVerdicts={};persist();}return n;
    }
    function getData(){return JSON.parse(JSON.stringify(data));}
    function setEnabled(v){enabled=!!v;}
    function exportText(){return JSON.stringify({exportedAt:new Date(clock()).toISOString(),notice:'Forward-only indicative paper results. Not actual fills or realized account profits.',...getData()},null,2);}
    function clear(){data=empty();persist();}
    return {record,onQuote,summary,markInterrupted,getData,exportText,clear,setEnabled};
  }
  function review(a,context={}){
    if(!a)return {bias:'분석 대기',status:'WAIT',why:'실제 시장 자료를 수신하기 전입니다.',next:'가격·수급·상위 시간봉 수신 필요'};
    const long=a.long||{},short=a.short||{};
    const l=safeNum(long.score,0),s=safeNum(short.score,0);
    const leader=l>=s?long:short,side=l>=s?'LONG':'SHORT';
    const gap=Math.abs(l-s);
    const bias=gap>=8?side:'중립';
    const status=context.stale||context.riskReason?'WAIT':(isSide(a.verdict)?a.verdict:'WAIT');
    const reasons=[];
    if(!context.stale){
      reasons.push(`${a.strategy?.title||'선택 전략'} · 지표 부합 LONG ${l}% / SHORT ${s}% (승률 아님)`);
      if(leader.rr!=null)reasons.push(`${side} TP1 순비용 손익비 1:${safeNum(leader.rr,0).toFixed(2)}`);
    }else reasons.push('시장 데이터가 오래되어 판단을 중단했습니다.');
    if(context.riskReason)reasons.push('계좌 위험 설정: '+context.riskReason);
    const next= status==='WAIT' ?
      ((leader.failed||[]).slice(0,3).join(' · ')||'반전·수급·손익비 재확인') :
      `${status} 조건부 진입 신호 · 실제 체결/수익 보장 아님`;
    return {bias,status,why:reasons.join(' · '),next};
  }
  function decisionPacket({symbol,mode,analysis,price,quoteAgeMs,bookAgeMs,leverage,margin,fee,slip,candles}={}){
    // Schema only. Sending to a remote model is explicitly NOT implemented.
    const a=analysis||{},i=a.indicators||{},c=Array.isArray(candles)?candles:[];
    const round=n=>Number.isFinite(n)?Number(n.toPrecision(10)):null;
    const side=p=>({signal:!!p?.confirmed,entry:round(safeNum(p?.entry)),stop:round(safeNum(p?.stop)),
      tp1:round(safeNum(p?.tp1)),tp2:round(safeNum(p?.tp2)),scoreNotProbability:round(safeNum(p?.score)),
      rrAfterEstimatedCost:round(safeNum(p?.rr)),waitKind:p?.waitKind||null,
      failed:Array.isArray(p?.failed)?p.failed.slice(0,10):[],source:p?.targetOrigin||null});
    const frames={};for(const [tf,row] of Object.entries(a.frames||{}))frames[tf]={trend:row?.trend||'WAIT',rsi:round(safeNum(row?.rsi)),atr:round(safeNum(row?.atr)),support:round(safeNum(row?.support)),resistance:round(safeNum(row?.resistance))};
    return {schema:'bybit-arena-evidence-v1',modelConnected:false,ordersEnabled:false,
      capturedAt:new Date().toISOString(),symbol:cleanSymbol(symbol),strategyMode:mode||null,
      lastTradePrice:round(safeNum(price)),dataAgesMs:{quote:round(safeNum(quoteAgeMs)),orderbook:round(safeNum(bookAgeMs))},
      technicals:{ema20:round(safeNum(i.ema20)),ema50:round(safeNum(i.ema50)),ema200:round(safeNum(i.ema200)),
        rsi14:round(safeNum(i.rsi)),macdHistogram:round(safeNum(i.macd)),atr14:round(safeNum(i.atr)),
        volumeRatio:round(safeNum(i.vr)),orderbookBidFraction:round(safeNum(i.imbalance)),
        openInterestDeltaPct:round(safeNum(i.oidelta)),fundingRate:round(safeNum(i.funding))},
      frames,long:side(a.long),short:side(a.short),localVerdict:a.verdict||'WAIT',
      riskSettings:{leverage:round(safeNum(leverage)),marginUsdt:round(safeNum(margin)),feeSide:round(safeNum(fee)),slippageSide:round(safeNum(slip))},
      mostRecentClosedCandles:c.slice(0,-1).slice(-24).map(b=>({timeMs:round(safeNum(b.t)),open:round(safeNum(b.o)),high:round(safeNum(b.h)),low:round(safeNum(b.l)),close:round(safeNum(b.c)),volume:round(safeNum(b.v))})),
      disclaimer:'Evidence snapshot only. Requires a secured backend and validated model before model predictions are possible.'};
  }
  return {create,review,decisionPacket};
})();
if(typeof module!=='undefined'&&module.exports)module.exports=DecisionLab;
