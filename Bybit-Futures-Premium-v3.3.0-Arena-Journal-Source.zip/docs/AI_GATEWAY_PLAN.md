# Phase 2 — Arena-inspired model-review gateway (NOT IMPLEMENTED)

## Why a separate server?

The Android WebView must NEVER contain OPENAI_API_KEY. A future private HTTPS backend should verify the calling user's session, apply per-user spending limits, rate limits and consent, gather/normalize public Bybit market data on the server, then call an available OpenAI model. No permission to trade should be required. No automatic order execution is proposed.

## Input JSON contract (implemented, available from the v3.3.0 performance dialog)

`DecisionLab.decisionPacket()` produces a versioned `bybit-arena-evidence-v1` snapshot including:
- freshness/quality of Bybit live quote and orderbook data
- selected symbol and scalp/short/long strategy
- indicators: EMA20/50/200, RSI14, MACD, ATR14, volume ratio, orderbook imbalance, OI delta, funding rate
- higher timeframe trend/support/resistance summaries
- both LONG and SHORT entry, structure-derived TP1/TP2, SL, fee-aware RR, blockers
- last 24 completed anchor candles (never the current incomplete candle)
- leverage, margin, fee and slippage assumptions.

The packet has explicit null values for missing observations; the model must never fill in missing Bybit data with invented numbers.

## Proposed model response (future schema)

```json
{
  "decision": "WAIT",
  "preferred_side": "LONG",
  "confidence_is_not_win_probability": "medium",
  "market_regime": "trend | range | volatile | unknown",
  "evidence_for": ["actual grounded signal"],
  "evidence_against": ["conflicting high timeframe trend"],
  "entry_zone": {"low": null, "high": null},
  "tp_zone": {"low": null, "high": null},
  "stop_price": null,
  "invalidate_if": "explicit condition",
  "missing_data": ["OI delta"],
  "review_time_seconds": 120,
  "model_version": "server-reported",
  "reason": "..."
}
```

The final app must recompute RR, ordering of TP/SL, fee/risk constraints and enforce stale-data WAIT **outside the LLM**. No model output, no matter how confident, may bypass risk gates. Do not treat model-generated percentages as calibrated win probabilities.

## Evaluation protocol

1. Collect live, timestamped signals before outcomes are known; never backfill unobserved market outcomes as wins.
2. For historical replay, freeze each decision at the original bar close; fetch only features that existed at that time, including OI/orderbook where actually available. Record data gaps and delisted symbols.
3. Use chronological walk-forward train/validation/test splits. Compare baseline v3.2.8, v3.2.9, v3.3 rules and LLM review using the **same data, timestamps, fills, fee/slippage model and risk limits**.
4. Count non-trades (WAIT ratio), trade frequency, TP/SL hit ratio, cost-adjusted net expectancy, profit factor, drawdown, time-in-trade, slippage sensitivity and data-staleness issues.
5. Minimum reproducibility conditions: fixed version hash, model name, prompt version, source-data timestamps, order/fee assumptions and time-zone; hold-out evaluation before claiming strategy quality.
6. Full real fill simulation would require historical orderbook/trade prints; candle high/low alone creates ambiguous TP-first/SL-first outcomes, which must be conservatively marked ambiguous or stop-first.

## Scope of first version

Version 3.3.0 is a **journal and indicative forward paper simulator**, not a historical backtester and not an API-linked AI trader. It is intentionally conservative in data integrity and transparent about missing periods. This is the first engineering milestone toward an evidence-driven, measurable AI analysis system.
