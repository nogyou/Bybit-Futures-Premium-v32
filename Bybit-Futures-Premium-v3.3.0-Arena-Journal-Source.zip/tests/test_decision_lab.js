'use strict';
const assert=require('node:assert/strict');
const Lab=require('../app/src/main/assets/decision-lab.js');
let now=1000000;const memory={};const storage={getItem:k=>memory[k]||null,setItem:(k,v)=>memory[k]=v};
const journal=Lab.create(storage,()=>now);
const analysis=(verdict='WAIT')=>({verdict,vreason:'시장 구조 검증',strategy:{title:'단타'},
 long:{kind:'LONG',score:75,rr:1.7,entry:100,tp1:102,stop:98,waitKind:'PRICE',failed:['가격 미도달']},
 short:{kind:'SHORT',score:48,rr:.5,entry:103,tp1:98,stop:106,waitKind:'RISK_REWARD',failed:['손익비 부족']}});
const snap=(verdict,at=now)=>({symbol:'BTCUSDT',mode:'scalp',analysis:analysis(verdict),verdict,at,closedBarTime:200000,
 price:100,margin:100,leverage:3,fee:.0006,slip:.0003,stale:false,riskReason:''});
assert.equal(journal.record(snap('WAIT')).added,true);
assert.equal(journal.record(snap('WAIT',now+50)).added,false,'same close+verdict must not inflate WAIT count');
assert.equal(journal.summary().waits,1);
assert.equal(journal.record(snap('LONG',now+80)).queued,true,'WAIT -> LONG queues paper order');
assert.equal(journal.summary().pending,1);
assert.equal(journal.record(snap('LONG',now+200)).added,false);
assert.equal(journal.onQuote('BTCUSDT',100,now+800).updated,1,'next quote, not signal tick, enters indicative paper');
assert.equal(journal.summary().open,1);
assert.equal(journal.onQuote('BTCUSDT',102.2,now+1200).updated,1);
let m=journal.summary();assert.equal(m.closed,1);assert.equal(m.wins,1);assert.ok(m.netPnl>0);
assert.ok(m.waitShare<1 && m.waitShare>0);
assert.equal(journal.getData().trades[0].status,'TP1');
assert.ok(journal.exportText().includes('Not actual fills'));
now+=3000;
const s2=snap('WAIT',now);s2.closedBarTime=500000;journal.record(s2);
const s3=snap('SHORT',now+10);s3.closedBarTime=500000;s3.price=103;
assert.equal(journal.record(s3).queued,true);
assert.equal(journal.onQuote('BTCUSDT',103,now+100).updated,1);
assert.equal(journal.onQuote('BTCUSDT',106.5,now+200).updated,1);
assert.equal(journal.summary().losses,1,'SL must count even if a quote gaps beyond it');
const risk=snap('LONG',now+300);risk.closedBarTime=900000;risk.riskReason='허용손실 초과';
assert.equal(journal.record(risk).decision.verdict,'WAIT','account risk may never be overwritten');
assert.equal(journal.getData().trades.length,2);
now+=4000;
const next=snap('LONG',now);next.closedBarTime=1000000;assert.equal(journal.record(next).queued,true);
assert.equal(journal.markInterrupted('APP_BACKGROUND'),1);
assert.equal(journal.summary().unverified,1);
// Reopen on same storage: incomplete trials must not be counted as realized losses.
const reopened=Lab.create(storage,()=>now+100);
assert.equal(reopened.summary().closed,2);
assert.equal(reopened.summary().unverified,1);
const review=Lab.review(analysis('WAIT'),{});
assert.equal(review.bias,'LONG');assert.equal(review.status,'WAIT');
assert.ok(review.next.includes('가격 미도달'));
assert.equal(Lab.review(analysis('LONG'),{stale:true}).status,'WAIT');
reopened.clear();assert.equal(reopened.summary().decisions,0);

// LLM-ready packet must never include the final still-forming candle or fabricate absent data.
const candles=Array.from({length:30},(_,i)=>({t:100000+i*300000,o:100+i,h:102+i,l:99+i,c:101+i,v:10+i}));
const packet=Lab.decisionPacket({symbol:'BTCUSDT',mode:'scalp',analysis:analysis('WAIT'),price:100,candles,quoteAgeMs:300,bookAgeMs:2000,leverage:3,margin:100,fee:.0006,slip:.0003});
assert.equal(packet.schema,'bybit-arena-evidence-v1');
assert.equal(packet.modelConnected,false);
assert.equal(packet.mostRecentClosedCandles.length,24);
assert.equal(packet.mostRecentClosedCandles.at(-1).timeMs,candles.at(-2).t);
assert.equal(packet.technicals.openInterestDeltaPct,null,'missing OI must stay missing');
assert.equal(packet.long.scoreNotProbability,75);
console.log('PASS 3.3 decision journal: WAIT dedup; next-quote entry; TP/SL; fees; risk; interrupted exclusion; restart; review.');
