'use strict';
const assert=require('node:assert/strict');
const Engine=require('../app/src/main/assets/engine.js');
const Comparison=require('../app/src/main/assets/comparison.js');
const Position=require('../app/src/main/assets/position.js');
let p=50000;
const bars=[];
for(let i=0;i<241;i++){
  const o=p; p+=Math.sin(i*.18)*32+Math.cos(i*.037)*9+3.5;
  bars.push({t:1700000000000+i*300000,o,h:Math.max(o,p)+12,l:Math.min(o,p)-14,c:p,v:70+((i*7)%51)});
}
const orderbook={b:Array.from({length:50},(_,i)=>[String(p-i),'4']),a:Array.from({length:50},(_,i)=>[String(p+i),'4'])};
const ticker=lastPrice=>({lastPrice:String(lastPrice),fundingRate:'0.0001'});
const options={strategyMode:'scalp',tickSize:0.1};
const base=Engine.analyze(bars,ticker(p),orderbook,null,options);
const up=Engine.analyze(bars,ticker(p+100),orderbook,null,options);
const down=Engine.analyze(bars,ticker(p-100),orderbook,null,options);
for(const side of ['long','short']){
  const a=base[side];
  assert.equal(a.entry,up[side].entry,side+': ticks must not cause entry to chase price');
  assert.equal(a.entry,down[side].entry,side+': ticks must not cause entry to chase price');
  assert.ok(['PRICE','RISK_REWARD','CONFIRMATION','DATA','TREND','INVALIDATED','READY'].includes(a.waitKind));
  assert.ok(a.considered>=1&&a.considered<=6);
  assert.ok(Number.isFinite(a.planningPrice));
}
const long={...base.long,entry:100,stop:99,tp1:102,tp2:NaN,rr:1.5,near:true,confirmed:true,canceled:false};
const short={...base.short,confirmed:false};
const a={verdict:'LONG',strategy:{key:'scalp'},long,short};
assert.equal(Comparison.compare(a,{stale:false}).verdict,'LONG','second target must not block a confirmed first-target trade');
const alert=Position.entryAlert({analysis:a,quoteAgeMs:1000,analysisAgeMs:1000,bookAgeMs:1000,maxLev:100,leverage:10});
assert.equal(alert.kind,'LONG','missing optional TP2 must not block alert');
assert.equal(alert.strong,true);
console.log('PASS v3.2.9: entry stable across live ticks, explanatory WAIT diagnostics, optional TP2 allowed, no fabricated target.');
