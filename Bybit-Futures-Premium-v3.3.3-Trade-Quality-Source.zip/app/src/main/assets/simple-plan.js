'use strict';
/* One readable conditional trade plan per selected investment horizon.
 * Uses ONLY existing, computed market-structure plans. Never invents entry/TP/SL.
 * A pending scenario is NOT an immediate trade signal or a guaranteed fill.
 */
const SimplePlan = (() => {
  const finite = v => Number.isFinite(v) && v > 0;
  function assess(plan, side, opts={}){
    const entry=plan?.entry, takeProfit=plan?.tp1, stop=plan?.stop;
    const dir=side==='LONG'?1:-1;
    const structural=finite(entry)&&finite(takeProfit)&&finite(stop)&&
      (takeProfit-entry)*dir>0&&(entry-stop)*dir>0;
    const net=Number.isFinite(plan?.netProfitPct)?plan.netProfitPct:null;
    const rr=Number.isFinite(plan?.rr)?plan.rr:null;
    const trendOpposed=plan?.setupType?.startsWith('역추세')||
      (opts.analysis?.trend?.direction && opts.analysis.trend.direction!=='MIXED'&&opts.analysis.trend.direction!==side);
    const verifiedEntry=!String(plan?.entrySource||'').includes('ATR 추정');
    const viable=structural && verifiedEntry && plan?.tradeViable===true && net>0 && rr>=1.5 &&
      (!Number.isFinite(plan?.minGrossPct)||Number(plan?.grossProfitPct)>=plan.minGrossPct) &&
      (!plan?.stopSource||!String(plan.stopSource).includes('부족')) &&
      !trendOpposed && !plan?.against && !plan?.canceled;
    const stale=!!opts.stale;
    const risk=opts.risks?.[side]||'';
    const live=finite(opts.current)?opts.current:opts.analysis?.livePrice;
    const gapPct=finite(live)&&finite(entry)?Math.abs(entry-live)/entry*100:null;
    let status='구조적 목표 불명 · 판단 보류';
    if(structural){
      if(!viable){
        if(!verifiedEntry)status='확인된 지지·저항 부족 · 진입 추천 아님';
        else if(trendOpposed)status='선택 전략과 반대 추세 · 진입 비추천';
        else if(plan?.canceled)status='진입 시나리오 무효';
        else if(net!==null&&net<=0)status='거래 비용 고려 시 이익 부족';
        else status='구조적 익절폭·수수료·손익비 기준 미달 · 진입 비추천';
      }else if(stale)status='시세·지표 갱신 대기 · 진입 금지';
      else if(risk)status='계좌 위험 한도 초과 · 진입 보류';
      else if(plan?.confirmed && opts.analysis?.verdict===side)status='현재 진입 조건 확인 · 위험 검토 필수';
      else if(plan?.near)status='가격대 근처 · 반전·수급 확인 대기';
      else status='진입 가격 도달 대기';
    }
    const ready=viable&&!stale&&!risk&&!!plan?.confirmed&&opts.analysis?.verdict===side;
    const available=viable&&!stale&&!risk;
    const reason=structural?`${plan.entrySource||'진입 구조 근거 부족'} · ${plan.tp1Reason||'익절 구조 근거 부족'} · ${plan.trendLabel||'추세 확인 중'}`:'지지·저항과 손절 구조를 동시에 확인하지 못함';
    // Favors feasible plans and a nearby entry, never raw direction scores alone.
    const rank=(ready?100:0)+(available?45:0)+Math.min(Math.max(rr||0,0),4)*7+
      (Number(plan?.score)||0)*.035-Math.min(gapPct||10,10)*.5;
    return {side,entry:structural?entry:null,takeProfit:structural?takeProfit:null,stop:structural?stop:null,
      netProfitPct:net,rr,viable,available,ready,structural,stale,status,reason,rank,gapPct,
      costPct:Number.isFinite(plan?.tradingCostPct)?plan.tradingCostPct:null,
      netLossPct:structural?((Math.abs(stop-entry)/entry*100)+(Number.isFinite(plan?.tradingCostPct)?plan.tradingCostPct:0)):null,
      signalConfirmed:ready,trend:plan?.trendLabel||'',entryReason:plan?.entrySource||'',exitReason:plan?.tp1Reason||'',stopReason:plan?.stopSource||'구조적 손절 참고',
      deniedReasons:Array.isArray(plan?.failed)?plan.failed.slice(0,3):[],
      grossProfitPct:Number.isFinite(plan?.grossProfitPct)?plan.grossProfitPct:null};
  }
  function build(analysis,opts={}){
    const current=finite(opts.current)?opts.current:analysis?.livePrice;
    const title=analysis?.strategy?.title||'선택 기간';
    if(!analysis)return {current,title,best:null,rows:[],headline:'시장 데이터 분석 대기',description:'유효한 시세와 분석봉이 도착하면 진입·익절 가격을 표시합니다.'};
    const rows=[assess(analysis.long,'LONG',{...opts,current,analysis}),assess(analysis.short,'SHORT',{...opts,current,analysis})];
    const candidates=rows.filter(p=>p.available).sort((a,b)=>b.rank-a.rank);
    const best=candidates[0]||null;
    const blocked=rows.filter(x=>x.viable&&!x.available);
    const headline=best?(best.ready?`${best.side} 진입 조건 확인`:`${best.side} 우선 감시 · 조건부 매매 시나리오`):
      blocked.length?'수익 조건 충족 후보 있으나 진입 보류':'현재 매매할 만한 가격 조합 없음';
    const description=best?(best.ready?'신호는 자동 주문이 아닙니다. 계좌와 호가를 확인하세요.':
      `${best.status} · 후보 가격은 시장이 바뀌면 다시 계산됩니다.`):
      blocked.length?blocked.map(x=>`${x.side}: ${x.status}`).join(' · '):'익절까지의 가격폭·수수료·손절 위험이 맞지 않아 추천을 보류합니다. 없는 기회를 만들어내지 않습니다.';
    return {current,title,best,rows,blocked,headline,description};
  }
  return {assess,build};
})();
if(typeof module!=='undefined'&&module.exports)module.exports=SimplePlan;
