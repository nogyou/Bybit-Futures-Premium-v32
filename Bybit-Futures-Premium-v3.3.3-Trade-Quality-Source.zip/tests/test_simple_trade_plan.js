'use strict';
const assert=require('node:assert/strict');
const SP=require('../app/src/main/assets/simple-plan.js');
const short={entry:120,tp1:100,stop:125,netProfitPct:16.5,tradingCostPct:.17,rr:3.5,tradeViable:true,
  confirmed:false,near:false,score:65,entrySource:'확인된 저항',tp1Reason:'지지선 100',trendLabel:'하락 배열'};
const long={entry:90,tp1:95,stop:88,netProfitPct:5.2,rr:2,tradeViable:false,confirmed:false,near:false,
  entrySource:'지지 후보',tp1Reason:'저항 후보',trendLabel:'하락 배열',setupType:'역추세 관찰 · 신규 진입 보류'};
const a={strategy:{title:'단타',anchor:'5'},trend:{direction:'SHORT'},long,short,verdict:'WAIT',livePrice:100};
const res=SP.build(a,{current:100,stale:false});
assert.equal(res.best.side,'SHORT');
assert.equal(res.best.entry,120);assert.equal(res.best.takeProfit,100);
assert.equal(res.best.ready,false);assert.match(res.best.status,/대기/);
assert.match(res.rows[0].status,/비추천/);
assert.equal(SP.build(a,{stale:true}).best,null,'stale quote must not promote a trade');
assert.equal(SP.build({...a,short:{...short,tp1:125}},{current:100}).best,null,'target must be below short entry');
assert.equal(SP.build({...a,short:{...short,tradeViable:false,netProfitPct:-.3}},{current:100}).best,null,'no fee-negative recommendations');
assert.equal(SP.build({...a,short:{...short,entrySource:'ATR 추정 · 지지저항 미확인'}},{current:100}).best,null,'ATR fallback alone cannot recommend');
const ready=SP.build({...a,verdict:'SHORT',short:{...short,confirmed:true,near:true}},{current:120});
assert.equal(ready.best.ready,true);
const stopRisk=SP.build({...a,verdict:'SHORT',short:{...short,confirmed:true,near:true}},{current:120,risks:{SHORT:'손실 예산 초과'}});
assert.equal(stopRisk.best,null);
console.log('PASS simple trade plan: real level selection, price waiting, stale, invalid TP, costs, risk');
