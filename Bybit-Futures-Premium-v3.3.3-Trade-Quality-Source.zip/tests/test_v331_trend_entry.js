'use strict';
const assert=require('node:assert/strict');
const Engine=require('../app/src/main/assets/engine.js');
const up=Engine.trendRegime(105,103,100,104,102);
assert.equal(up.direction,'LONG');
assert.equal(Engine.trendRegime(95,97,100,96,98).direction,'SHORT');
assert.equal(Engine.trendRegime(100,99,101,101,98).direction,'MIXED');
const base=1700000000000;let price=60000;const data=[];
for(let i=0;i<241;i++){
  const o=price;price+=15+Math.sin(i*.39)*28;const c=price;
  data.push({t:base+i*300000,o,h:Math.max(o,c)+23,l:Math.min(o,c)-28,c,v:150+(i%8)*8});
}
const emaSample=Array.from({length:70},()=>103),candles=Array.from({length:70},(_,i)=>({o:103.5,h:104.5,l:i<60?103.3:103,c:104}));
assert.ok(Engine.maRetestCandidates(candles,105,1,'LONG',{e20:emaSample,e50:Array(70).fill(99)}).length>0);
assert.equal(Engine.maRetestCandidates(candles,105,1,'SHORT',{e20:emaSample,e50:Array(70).fill(99)}).length,0);
const orderbook={b:Array.from({length:50},(_,i)=>[String(price-i*.1),'3']),a:Array.from({length:50},(_,i)=>[String(price+i*.1),'3'])};
const opts={strategyMode:'scalp',tickSize:.1,feeSide:.0006,slipSide:.00025};
const analysed=Engine.analyze(data,{lastPrice:String(price),fundingRate:'.0001'},orderbook,null,opts);
for(const k of ['long','short']){
  const plan=analysed[k];
  assert.ok(['EMA 재시험 후보','추세 방향 지지·저항 후보','역추세 관찰 · 신규 진입 보류','혼조 구간 · 추가 확인 필요'].includes(plan.setupType));
  assert.ok(Math.abs(plan.tradingCostPct-.17)<1e-9);
  assert.ok(Number.isFinite(plan.netProfitPct));
  assert.ok(!plan.tradeViable||plan.rr>=1.5);
  assert.ok(!plan.tradeViable||plan.netProfitPct>=plan.minNetProfitPct);
  if(plan.netProfitPct<=0)assert.equal(plan.tradeViable,false);
  if(plan.setupType==='역추세 관찰 · 신규 진입 보류')assert.equal(plan.confirmed,false);
}
const retick=Engine.analyze(data,{lastPrice:String(price*1.003),fundingRate:'.0001'},orderbook,null,opts);
assert.equal(retick.long.entry,analysed.long.entry);
assert.equal(retick.short.entry,analysed.short.entry);
// Verify the user's quoted example is not positive after the app's own default friction estimate.
const gross=(59945.8-59870.3)/59870.3*100;
assert.ok(gross<.17);
console.log('PASS v3.3.1 EMA retests, directional regime, after-cost quality gates, stable entries');
