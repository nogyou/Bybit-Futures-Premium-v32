"use strict";
const assert=require('node:assert/strict');
const E=require('../app/src/main/assets/engine.js');
const P=require('../app/src/main/assets/simple-plan.js');
const {readFileSync}=require('node:fs');
const valid={entry:100,tp1:103,stop:99,rr:2.5,tradeViable:true,minGrossPct:.5,grossProfitPct:3,netProfitPct:2.83,tradingCostPct:.17,stopSource:'확정된 고저점 이탈',entrySource:'확정 저점 지지',tp1Reason:'3회 확인된 전고점',confirmed:false,near:false,score:74,trendLabel:'상승 추세'};
const a={strategy:{title:'단타',anchor:'5'},trend:{direction:'LONG',label:'상승 배열'},long:valid,short:{...valid,entry:104,stop:105,tp1:102,netProfitPct:1.83,grossProfitPct:2,tradeViable:false},verdict:'WAIT',livePrice:101};
let p=P.build(a,{current:101});
assert.equal(p.best.side,'LONG');
assert.equal(p.best.entry,100);
assert.ok(p.best.netLossPct>1);
assert.ok(p.best.netProfitPct>0);
assert.equal(p.best.ready,false,'candidate must not be an instant order');
assert.equal(P.build({...a,long:{...valid,netProfitPct:-.044}},{current:101}).best,null,'fee-negative candidate suppressed');
assert.equal(P.build({...a,long:{...valid,grossProfitPct:.3}},{current:101}).best,null,'close target cannot bypass friction-to-target gate');
assert.equal(P.build({...a,long:{...valid,rr:.1}},{current:101}).best,null,'low risk/reward rejected');
assert.equal(P.build({...a,long:{...valid,stopSource:'구조적 손절 근거 부족'}},{current:101}).best,null,'guesswork ATR stop rejected');
assert.equal(P.build(a,{current:101,stale:true}).best,null,'stale price blocks recommendation');
assert.equal(P.build(a,{current:101,risks:{LONG:'손절 손실 한도 초과'}}).best,null,'account risk blocks recommendation');
assert.match(P.build(a,{current:101,risks:{LONG:'손절 손실 한도 초과'}}).headline,/진입 보류/);
const rows=[];let price=100;
for(let i=0;i<242;i++){const o=price;price+=.08+Math.sin(i*.32)*.23;rows.push({t:1700000000000+i*300000,o,h:Math.max(o,price)+.22,l:Math.min(o,price)-.24,c:price,v:100+(i%9)*12});}
const ticker={lastPrice:String(price),fundingRate:'.0001'};
const ob={b:[[String(price-.01),'20']],a:[[String(price+.01),'22']]};
const cfg={tickSize:.01,feeSide:.0006,slipSide:.00025,strategyMode:'scalp'};
const analysis=E.analyze(rows,ticker,ob,null,cfg);
for(const side of ['long','short']){
  const c=analysis[side];
  if(c.tradeViable){assert.ok(c.grossProfitPct>=c.minGrossPct);assert.ok(c.rr>=1.5);assert.ok(c.stopSource.includes('고저점'));}
}
const altered=rows.slice();altered[altered.length-1]={...altered.at(-1),h:100000,l:1,c:123456};
const b=E.analyze(altered,ticker,ob,null,cfg);
assert.equal(analysis.long.entry,b.long.entry,'forming candle cannot alter plan');
assert.equal(analysis.short.entry,b.short.entry,'forming candle cannot alter plan');
assert.match(readFileSync(require('node:path').join(__dirname,'../app/src/main/assets/index.html'),'utf8'),/분석 → 진입 → 익절·손절/);
const workflow=readFileSync(require('node:path').join(__dirname,'../.github/workflows/android.yml'),'utf8');
assert.match(workflow,/unzip -o Bybit-Futures-Premium-v3\.3\.(?:3-Trade-Quality|4-Live-Scalping)-Source\.zip/);
assert.match(workflow,/grep '3\\.3\\.[34]'/);
console.log('PASS v3.3.3: 3-step plan, costs, net R, structural stop, quote delay, long/short, closed-candle invariant');
