'use strict';
/* Forward-only verification of the app's ORIGINAL, frozen price recommendations.
   A recommended LIMIT AREA is not a confirmed trade. Only a later confirmed signal
   may create a hypothetical next-quote fill. This never executes an exchange order.
   Quotes are NOT exchange fills. Disconnects/hidden app cannot be backfilled here.
 */
const ScenarioVerifier=(()=>{
  const STORAGE='v336-recommendation-verifier-v1',MAX=500;
  const MAX_AGE={live:35*60000,scalp:3*3600000,short:3*86400000,long:21*86400000};
  const isSide=s=>s==='LONG'||s==='SHORT';
  const isActive=s=>['WATCH','TOUCHED','PENDING','OPEN'].includes(s);
  const number=x=>x===null||x===undefined||x===''?NaN:Number(x);
  const safe=(v,d)=>Number.isFinite(number(v))?number(v):d;
  function create(storage,clock=()=>Date.now()){
    let items=[],seq=0,enabled=true,persistOK=true;
    try{const raw=JSON.parse(storage?.getItem(STORAGE)||'null');if(raw?.version===1&&Array.isArray(raw.items)){
      items=raw.items.slice(-MAX);seq=safe(raw.seq,items.length);
    }}catch(_){persistOK=false;}
    const save=()=>{try{if(!storage?.setItem){persistOK=false;return;}storage.setItem(STORAGE,JSON.stringify({version:1,seq,items}));persistOK=true;}catch(_){persistOK=false;}};
    // Without a continuous quote feed, prices crossing TP/SL while app was closed
    // are UNKNOWN, not wins, not losses.
    let resumed=false;
    for(const p of items){if(isActive(p.status)){
      p.status='UNVERIFIED';p.note='앱 종료/재시작 동안 가격 추적 불가';p.closedAt=clock();resumed=true;
    }}
    if(resumed)save();
    function expire(at){let changed=false;
      for(const p of items){if(!isActive(p.status))continue;
        if(at-p.createdAt>MAX_AGE[p.mode]){
          p.status=p.status==='WATCH'||p.status==='TOUCHED'?'EXPIRED':'UNVERIFIED';
          p.note=p.status==='EXPIRED'?'진입 신호 없이 관측 기간 종료':'신호 또는 추적 기간 종료 · 결과 미검증';
          p.closedAt=at;changed=true;
        }
      }if(changed)save();return changed;
    }
    function propose(v){
      if(!enabled||!v||!isSide(v.side)||!['live','scalp','short','long'].includes(v.mode))return null;
      const symbol=String(v.symbol||'').replace(/[^A-Z0-9]/g,'');
      const entry=number(v.entry),tp=number(v.tp),sl=number(v.sl),quote=number(v.price),now=safe(v.at,clock());
      const dir=v.side==='LONG'?1:-1;
      if(!symbol||![entry,tp,sl,quote].every(n=>Number.isFinite(n)&&n>0)||!(dir*(tp-entry)>0&&dir*(entry-sl)>0)||v.viable!==true||v.stale===true)return null;
      expire(now);
      // Do not replace a published price plan with an opportunistically moving target.
      const same=items.slice().reverse().find(p=>p.symbol===symbol&&p.mode===v.mode&&p.side===v.side&&isActive(p.status));
      // No hindsight-driven repeated opportunity from the same completed bar.
      const duplicate=items.slice().reverse().find(p=>p.symbol===symbol&&p.mode===v.mode&&p.side===v.side&&p.barTime&&p.barTime===safe(v.barTime,0));
      if(!same&&duplicate)return duplicate;
      if(same&&['WATCH','TOUCHED'].includes(same.status)&&v.barTime&&same.barTime!==v.barTime&&
          (Math.abs(entry-same.entry)/same.entry>.001 || Math.abs(tp-same.tp)/same.tp>.002 || Math.abs(sl-same.sl)/same.sl>.002)){
        same.status='SUPERSEDED';same.note='새로운 완성봉에서 추천 가격이 변경되어 기존 후보 종료';same.closedAt=now;save();
      }else if(same){
        // Same immutable active recommendation remains observable; only an explicitly
        // matching signal may confirm it. A changed price is a new proposed setup,
        // not a retroactive rewrite of the old setup.
        confirm(same,v,now);
        return same;
      }
      if(items.length>=MAX){const cut=items.findIndex(p=>!isActive(p.status));if(cut>=0)items.splice(cut,1);else return null;}
      const p={id:'S'+(++seq)+'-'+now,symbol,mode:v.mode,side:v.side,
        createdAt:now,barTime:safe(v.barTime,0),entry,tp,sl,signalPrice:quote,
        fee:Math.max(0,safe(v.fee,.0006)),slip:Math.max(0,safe(v.slip,.00025)),
        leverage:Math.max(1,Math.min(20,safe(v.leverage,10))),margin:Math.max(1,safe(v.margin,100)),
        evidence:String(v.evidence||'차트 분석').slice(0,200),status:'WATCH',touchAt:null,confirmAt:null,
        fillAt:null,fill:null,closedAt:null,exit:null,netPnl:null,netRoi:null,
        lastQuoteAt:now,referencePrice:quote,note:'추천 가격 도달 및 진입 신호 확인 대기'};
      items.push(p);confirm(p,v,now);save();return p;
    }
    function confirm(p,v,at){
      if(!isActive(p.status)||p.status==='PENDING'||p.status==='OPEN')return;
      const entry=number(v.entry),tp=number(v.tp),sl=number(v.sl),quote=number(v.price);
      // Never substitute newer targets for the original logged trade plan.
      const match=Math.abs(entry-p.entry)/p.entry<=.0008&&Math.abs(tp-p.tp)/p.tp<=.001&&Math.abs(sl-p.sl)/p.sl<=.001;
      const near=Number.isFinite(quote)&&Math.abs(quote-p.entry)/p.entry<=.001;
      if(!near||!match||v.verdict!==p.side||v.confirmed!==true)return;
      p.status='PENDING';p.confirmAt=at;p.lastQuoteAt=at;p.note='진입 조건 확인 · 다음 관측 시세로 가상 체결 검증 대기';save();
    }
    function onQuote(symbol,price,at=clock()){
      if(!enabled)return 0;
      at=number(at);price=number(price);symbol=String(symbol||'').replace(/[^A-Z0-9]/g,'');
      if(!symbol||![price,at].every(Number.isFinite)||price<=0)return 0;
      let changed=0;
      for(const p of items){if(p.symbol!==symbol||!isActive(p.status))continue;
        if(at<=p.lastQuoteAt)continue;
        const maxGap=p.mode==='live'?20000:120000;
        if(at-p.lastQuoteAt>maxGap){p.status='UNVERIFIED';p.note='시세 관측 공백 · 가격 도달 순서 확인 불가';p.closedAt=at;changed++;continue;}
        const dir=p.side==='LONG'?1:-1;
        if(p.status==='WATCH'||p.status==='TOUCHED'){
          // Price entry TOUCH only; NOT a simulated executed order.
          const crossed=(p.referencePrice-p.entry)*(price-p.entry)<=0;
          if((crossed||Math.abs(price-p.entry)/p.entry<=.001)&&!p.touchAt){
            p.touchAt=at;p.status='TOUCHED';p.note='추천 가격 도달 관측 · 진입 신호 미확인';changed++;
          }
          p.referencePrice=price;p.lastQuoteAt=at;continue;
        }
        if(p.status==='PENDING'){
          if(at-p.confirmAt>(p.mode==='live'?15000:60000)){
            p.status='UNVERIFIED';p.note='신호 후 가상 체결을 확인할 새 시세 부족';p.closedAt=at;changed++;continue;
          }
          const fill=price*(1+dir*p.slip);
          if(dir*(p.tp-fill)<=0||dir*(fill-p.sl)<=0){
            p.status='UNVERIFIED';p.note='다음 관측 시세가 이미 목표·손절 범위 밖 · 체결 가정 불가';p.closedAt=at;changed++;continue;
          }
          p.status='OPEN';p.fill=fill;p.fillAt=at;p.touchAt??=p.confirmAt;p.lastQuoteAt=at;
          p.note='실제 주문 아님 · 다음 관측 시세로 가상 체결 중';changed++;continue;
        }
        if(p.status==='OPEN'){
          const tpHit=dir*(price-p.tp)>=0,slHit=dir*(price-p.sl)<=0;
          if(tpHit||slHit){
            p.status=slHit?'SL':'TP';p.closedAt=at;
            // At TP, assume target price, never a better unconfirmed exit. On stop
            // gaps use observed worse price; fees and slip on both directions.
            const base=slHit?(dir>0?Math.min(price,p.sl):Math.max(price,p.sl)):p.tp;
            p.exit=base*(1-dir*p.slip);
            const notional=p.margin*p.leverage;
            const gross=dir*(p.exit-p.fill)/p.fill;
            const feeCost=p.fee*(1+p.exit/p.fill);
            p.netPnl=(gross-feeCost)*notional;
            p.netRoi=p.netPnl/p.margin*100;
            p.note=slHit?'관측 가격이 손절선 도달 · 실제 체결 아님':'관측 가격이 익절선 도달 · 실제 체결 아님';changed++;
          }else p.lastQuoteAt=at;
        }
      }
      if(expire(at))changed++;
      if(changed)save();return changed;
    }
    function interrupt(why='앱 비활성화 · 이후 경로 알 수 없음'){
      let n=0;for(const p of items)if(isActive(p.status)){p.status='UNVERIFIED';p.note=why;p.closedAt=clock();n++;}
      if(n)save();return n;
    }
    function summary(mode=null){
      const rows=items.filter(p=>!mode||p.mode===mode);
      const tp=rows.filter(p=>p.status==='TP'),sl=rows.filter(p=>p.status==='SL'),closed=[...tp,...sl];
      const pnl=closed.reduce((n,p)=>n+p.netPnl,0);
      return {total:rows.length,watch:rows.filter(p=>['WATCH','TOUCHED'].includes(p.status)).length,
        touched:rows.filter(p=>!!p.touchAt).length,open:rows.filter(p=>['PENDING','OPEN'].includes(p.status)).length,
        tp:tp.length,sl:sl.length,completed:closed.length,winRate:closed.length?tp.length/closed.length:null,
        pnl,average:closed.length?pnl/closed.length:null,
        unknown:rows.filter(p=>['UNVERIFIED','EXPIRED','SUPERSEDED'].includes(p.status)).length,rows:rows.slice().reverse(),persistOK};
    }
    function getAll(){return JSON.parse(JSON.stringify(items));}
    function clear(){items=[];seq=0;save();}
    function exportText(){return JSON.stringify({at:new Date(clock()).toISOString(),disclaimer:'Observed next-tick scenario simulation, not actual exchange executions or a historic backtest.',items:getAll()},null,2);}
    return {propose,onQuote,interrupt,summary,getAll,clear,exportText,expire};
  }
  return {create};
})();
if(typeof module!=='undefined'&&module.exports)module.exports=ScenarioVerifier;
