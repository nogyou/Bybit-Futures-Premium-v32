'use strict';
const assert=require('node:assert/strict');
const Verifier=require('../app/src/main/assets/scenario-verifier.js');
const mem={};const storage={getItem:k=>mem[k]||null,setItem:(k,v)=>mem[k]=v};
let now=1_700_000_000_000;let v=Verifier.create(storage,()=>now);
const raw=(over={})=>({symbol:'BTCUSDT',mode:'live',side:'LONG',entry:100,tp:102,sl:99,price:102,
  at:now,barTime:1_700_000_000_000-60000,leverage:10,margin:100,fee:.00055,slip:.0002,
  viable:true,verdict:'WAIT',confirmed:false,stale:false,evidence:'EMA + 저점 반등',...over});
const a=v.propose(raw());assert.equal(a.status,'WATCH');assert.equal(v.summary().total,1);
assert.equal(v.propose(raw({price:101})).id,a.id,'candidate prices must never be rewritten');
assert.equal(v.getAll()[0].tp,102);
now+=2000;v.onQuote('BTCUSDT',100,now);
assert.equal(v.getAll()[0].status,'TOUCHED','price touch is NOT a winning trade');
assert.equal(v.summary().completed,0);
// All subsequent quote updates are observed, not retroactive fills.
now+=1500;v.propose(raw({price:100,at:now,verdict:'LONG',confirmed:true}));
assert.equal(v.getAll()[0].status,'PENDING');
now+=1000;v.onQuote('BTCUSDT',100.05,now);assert.equal(v.getAll()[0].status,'OPEN');
now+=1000;v.onQuote('BTCUSDT',102.5,now);
assert.equal(v.getAll()[0].status,'TP');assert.equal(v.summary().tp,1);assert.ok(v.summary().pnl>0);
assert.equal(v.propose(raw({price:101})).id,a.id,'same bar cannot inflate count after closure');
// Realized loss via observed gap worse than stop.
now+=70000;const b=v.propose(raw({barTime:now-60000,price:100,at:now,verdict:'LONG',confirmed:true}));
assert.equal(b.status,'PENDING');
now+=1000;v.onQuote('BTCUSDT',100,now);now+=1000;v.onQuote('BTCUSDT',97.5,now);
assert.equal(v.summary().sl,1);assert.ok(v.getAll().at(-1).netPnl<0);
assert.equal(v.summary().winRate,.5);
// Invalid structure is never recorded.
assert.equal(v.propose(raw({tp:99})),null);
// A quote gap cannot be assumed to hit TP or SL.
now+=70000;const c=v.propose(raw({barTime:now-60000,at:now,price:100,verdict:'LONG',confirmed:true}));
now+=1000;v.onQuote('BTCUSDT',100.0,now);now+=25000;v.onQuote('BTCUSDT',103,now);
assert.equal(v.getAll().at(-1).status,'UNVERIFIED');assert.equal(v.summary().tp,1);
// App hidden / restart invalidates any unobserved trade or recommendation.
now+=70000;v.propose(raw({barTime:now-60000,at:now,price:102}));
assert.equal(v.interrupt(),1);
now+=70000;v.propose(raw({barTime:now-60000,at:now,price:102}));
v=Verifier.create(storage,()=>now+100);
assert.equal(v.getAll().at(-1).status,'UNVERIFIED');
assert.ok(v.exportText().includes('not actual exchange executions'));
const sum=v.summary();assert.equal(sum.completed,2);assert.equal(sum.total,5);
// Revised structure: freeze old candidate, mark superseded rather than rewriting
// the published targets to fit a later price move.
now+=100000;const d=v.propose(raw({mode:'short',barTime:now-40000,at:now,price:101}));
const d2=v.propose(raw({mode:'short',barTime:now+60000,at:now+65000,entry:101,tp:103,sl:100,price:102}));
assert.notEqual(d.id,d2.id);assert.equal(v.getAll().find(x=>x.id===d.id).status,'SUPERSEDED');

v.clear();assert.equal(v.summary().total,0);
console.log('PASS scenario verifier: immutable plan, WATCH != TP, signal confirmation, next-tick hypothetical fills, TP/SL first-observed, fees, loss gap, no future inference, local reload');
