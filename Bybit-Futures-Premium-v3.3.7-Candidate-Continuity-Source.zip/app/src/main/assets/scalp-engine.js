'use strict';
/* 실시간 스캘핑 실험 엔진: 공개시장 데이터의 완성된 캔들만 참조한다.
   주문 API/AI API/학습된 승률 모델이 아니며 확인된 저항·지지 밖으로 목표가를 연장하지 않는다. */
const ScalpEngine=(()=>{
  const finite=x=>Number.isFinite(x),clamp=(x,a,b)=>Math.max(a,Math.min(b,x));
  const pct=(a,b)=>b>0?(a/b)*100:NaN;
  const mean=a=>a.length?a.reduce((x,y)=>x+y,0)/a.length:NaN;
  const roundTick=(x,t)=>finite(t)&&t>0?Math.round(x/t)*t:x;
  const closed=(bars,minutes,now)=>Array.isArray(bars)?bars.filter(x=>finite(+x.t)&&finite(+x.c)&&finite(+x.h)&&finite(+x.l)&&x.h>=x.l&&x.t+minutes*60000<=now+1000).sort((a,b)=>a.t-b.t):[];
  function levels(bars,kind){
    const out=[];const n=bars.length;const high=kind==='HIGH';
    for(let i=Math.max(2,n-100);i<n-2;i++){
      const v=high?bars[i].h:bars[i].l;
      if(high?v>=bars[i-1].h&&v>=bars[i-2].h&&v>bars[i+1].h&&v>bars[i+2].h:
        v<=bars[i-1].l&&v<=bars[i-2].l&&v<bars[i+1].l&&v<bars[i+2].l){
        out.push({price:+v,source:'완성봉 확정 '+(high?'고점 저항':'저점 지지'),strength:2.3+(i>n-40?.45:0)});
      }
    }
    for(const width of [18,42,80]){
      if(n<width)continue;const last=bars.slice(-width);
      out.push({price:high?Math.max(...last.map(b=>b.h)):Math.min(...last.map(b=>b.l)),source:`${width}봉 ${high?'전고점':'전저점'}`,strength:width>=42?3.1:2.6});
    }
    return out.filter(x=>finite(x.price)&&x.price>0);
  }
  function bookBuyShare(book){
    if(!Array.isArray(book?.b)||!Array.isArray(book?.a))return null;
    const total=xs=>xs.slice(0,20).reduce((s,a)=>s+(+a[0])*(+a[1]),0);
    const b=total(book.b),a=total(book.a);return b+a>0?b/(b+a):null;
  }
  function analyze(input){
    const now=input?.now??Date.now(),quote=Number(input?.price),t=Number(input?.tickSize),fee=Number(input?.feeSide??.0006),slip=Number(input?.slipSide??.00025);
    const cost=clamp((Math.max(0,fee)+Math.max(0,slip))*2,0,.04);
    const s={verdict:'WAIT',phase:'데이터 수신 대기',reason:'완성봉 및 현재가 확인 중',quote,updatedAt:now,plans:[],plan:null,condition:'',inputs:{}};
    if(!finite(quote)||quote<=0||!finite(input?.quoteTime)||now-input.quoteTime>22000||now<input.quoteTime-3000){s.phase='시세 지연';s.reason='현재가 수신이 22초 이상 지연되었습니다. 새 진입 신호 중단';return s;}
    const one=closed(input.candles1,1,now),three=closed(input.candles3,3,now),five=closed(input.candles5,5,now);
    const a=one.at(-1),b=three.at(-1),c=five.at(-1);
    if(one.length<85||three.length<40||five.length<85||!a||!b||!c){s.phase='시간봉 부족';s.reason='1·3·5분 완성봉 데이터 부족';return s;}
    if(now-(a.t+60000)>90000||now-(b.t+180000)>210000||now-(c.t+300000)>330000){s.phase='시간봉 지연';s.reason='최신 완성봉이 오래되었습니다. 신규 진입 보류';return s;}
    const ema=TradeEngine.ema,atr=TradeEngine.atr,rsi=TradeEngine.rsi,macd=TradeEngine.macd;
    const p1=one.map(x=>+x.c),p3=three.map(x=>+x.c),p5=five.map(x=>+x.c);
    const e9_1=ema(p1,9),e20_1=ema(p1,20),e9_3=ema(p3,9),e20_3=ema(p3,20),e20_5=ema(p5,20),e50_5=ema(p5,50);
    const aa=atr(one).at(-1),a5=atr(five).at(-1),rr=rsi(p1).at(-1),hist=macd(p1).hist;
    if(![e9_1.at(-1),e20_1.at(-1),e9_3.at(-1),e20_3.at(-1),e20_5.at(-1),e50_5.at(-1),aa,a5,rr,hist.at(-1),hist.at(-2)].every(finite)||aa<=0||a5<=0){s.phase='지표 부족';s.reason='EMA·RSI·MACD·ATR 계산 불가';return s;}
    const vprev=mean(one.slice(-21,-1).map(x=>+x.v||0)),vr=vprev>0?(+a.v)/vprev:0;
    const imbalance=bookBuyShare(input.orderbook),costPct=cost*100;
    const twap=one.slice(-40);const vtotal=twap.reduce((sum,x)=>sum+(+x.v||0),0);
    const vwap=vtotal>0?twap.reduce((sum,x)=>sum+((x.h+x.l+x.c)/3)*(+x.v||0),0)/vtotal:NaN;
    const trend5=e20_5.at(-1)>e50_5.at(-1)&&e20_5.at(-1)>e20_5.at(-4)?'LONG':e20_5.at(-1)<e50_5.at(-1)&&e20_5.at(-1)<e20_5.at(-4)?'SHORT':'RANGE';
    const bias15=input.higher15?.trend||'WAIT';
    const hi=[...levels(five,'HIGH'),...levels(three,'HIGH').map(x=>({...x,strength:x.strength*.55})),...levels(one,'HIGH').map(x=>({...x,strength:x.strength*.36}))];
    const lo=[...levels(five,'LOW'),...levels(three,'LOW').map(x=>({...x,strength:x.strength*.55})),...levels(one,'LOW').map(x=>({...x,strength:x.strength*.36}))];
    s.inputs={trend5,trend15:bias15,ema9:e9_1.at(-1),ema20:e20_1.at(-1),ema20_5:e20_5.at(-1),ema50_5:e50_5.at(-1),rsi:rr,volumeRatio:vr,bookBuyShare:imbalance,atr1:aa,atr5:a5,vwap,costPct,barTime:a.t};
    const planFor=side=>{
      const dir=side==='LONG'?1:-1;
      const aligned=trend5===side;
      const trend1=dir*(e9_1.at(-1)-e20_1.at(-1))>0;
      const trend3=dir*(e9_3.at(-1)-e20_3.at(-1))>0;
      const hi15=!!input.higher15&&(bias15===side||bias15==='WAIT');
      const rsiPass=dir>0?(rr>=40&&rr<=70):(rr>=30&&rr<=60);
      const momentumPass=dir*(hist.at(-1)-hist.at(-2))>0;
      const candlePass=dir*(a.c-a.o)>0&&dir*(a.c-one.at(-2).c)>=0;
      const liquidity=vr>=1.05||(imbalance!==null&&(dir>0?imbalance>.54:imbalance<.46));
      const trendScore=(trend1?1:0)+(trend3?1:0)+(momentumPass?1:0)+(rsiPass?1:0);
      // Trend and historical location determine entries; raw ticker changes do not fabricate a level.
      const anchors=(dir>0?lo:hi).map(x=>({...x,origin:'확정 가격 구조'}));
      const emaTouch=(xs,value,tol)=>xs.slice(-12).some(x=>x.l<=value+tol&&x.h>=value-tol);
      if(emaTouch(one,e20_1.at(-1),aa*.45))anchors.push({price:e20_1.at(-1),strength:2.5,source:'EMA20 1분 재시험',origin:'EMA 완성봉 접촉'});
      if(emaTouch(five,e20_5.at(-1),a5*.40))anchors.push({price:e20_5.at(-1),strength:2.6,source:'EMA20 5분 재시험',origin:'EMA 완성봉 접촉'});
      // A prospective scalp limit entry cannot be many ATRs away from the current quote.
      const nearLimit=Math.max(a5*2.5,quote*.012),closeTolerance=Math.max(aa*.6,quote*.0004);
      const candidateAnchors=anchors.filter(x=>dir*(quote-x.price)>=-closeTolerance&&Math.abs(quote-x.price)<nearLimit);
      const plans=[];
      for(const spot of candidateAnchors){
        const entry=roundTick(spot.price,t),stopBarrier=dir>0?
          Math.min(...one.slice(-12).map(x=>x.l),spot.price-aa*.45):
          Math.max(...one.slice(-12).map(x=>x.h),spot.price+aa*.45);
        const stop=roundTick(stopBarrier-dir*aa*.18,t),risk=dir*(entry-stop);
        if(!finite(entry)||!finite(stop)||entry<=0||risk<=Math.max(0,entry*.0001))continue;
        // TP from a historical high/low: the first material barrier cannot be silently skipped.
        const targets=(dir>0?hi:lo).filter(x=>x.strength>=2.3&&dir*(x.price-entry)>Math.max(a5*.55,entry*.0003)&&dir*(x.price-entry)<=a5*9)
          .sort((x,y)=>dir*(x.price-y.price));
        const tolerance=Math.max(aa*.28,entry*.00015);
        const distinct=[];for(const z of targets){if(distinct.some(v=>Math.abs(v.price-z.price)<tolerance))continue;distinct.push(z);}
        if(!distinct.length)continue;
        // Market structure resistance/support before a more distant TP must be respected.
        const tpZone=distinct[0];const tp=roundTick(tpZone.price,t),gross=dir*(tp-entry)/entry;
        const net=gross-cost,loss=risk/entry+cost,ratio=net/loss;
        const meaningful=gross>=cost*3&&gross>=Math.max(.001,aa/entry*.65);
        const quality=meaningful&&ratio>=1.5&&net>0;
        const distance=Math.abs(quote-entry);
        const maxProfit=Number(input.margin||100)*Number(input.leverage||10)*net;
        const maxLoss=Number(input.margin||100)*Number(input.leverage||10)*loss;
        const riskOk=Number.isFinite(maxLoss)&&maxLoss<=Number(input.lossBudget??10)&&Number(input.leverage||10)<=20;
        const confirmations=aligned&&hi15&&trend1&&trend3&&candlePass&&liquidity&&trendScore>=3;
        const ready=quality&&riskOk&&confirmations&&distance<=closeTolerance;
        const severity=(quality?20:0)+(aligned?10:0)+(hi15?4:0)+trendScore*2+(spot.strength||0)*.6+(ready?8:0)-distance/Math.max(aa,1)*.9;
        plans.push({side,entry,stop,tp,rr:ratio,grossProfitPct:gross*100,netProfitPct:net*100,netLossPct:loss*100,profitUsdt:maxProfit,lossUsdt:maxLoss,
          quality,riskOk,confirmations,ready,near:distance<=closeTolerance,distance,priceGapPct:pct(distance,entry),score:severity,
          entryReason:spot.source,exitReason:tpZone.source,trend:trend5,trend1,trend3,volumeRatio:vr,
          blockers:[!aligned?'5분 추세 불일치':'',!hi15?(input.higher15?'15분 방향 상충':'15분 자료 미수신'):'',!trend1||!trend3?'1·3분 EMA 방향 미확인':'',!candlePass?'완성봉 반전 미확인':'',!liquidity?'거래량·호가 확인 부족':'',!quality?'수수료 차감 후 손익비·수익폭 부족':'',!riskOk?'선택 배율·허용손실 초과':'',distance>closeTolerance?'진입가 미도달':''].filter(Boolean)});
      }
      return plans.sort((x,y)=>y.score-x.score)[0]||null;
    };
    const both=[planFor('LONG'),planFor('SHORT')].filter(Boolean);
    s.plans=both;
    const acceptable=both.filter(x=>x.quality&&x.riskOk).sort((x,y)=>y.score-x.score);
    s.plan=acceptable[0]||null;
    if(!s.plan){s.phase='유효한 매매 가격 없음';s.reason=both.length?'수수료·손익비·손절 위험을 통과한 가격 조합 없음':'근거 있는 진입·익절 가격대가 아직 없음';return s;}
    const ready=acceptable.filter(x=>x.ready);
    if(ready.length===1){s.verdict=ready[0].side;s.plan=ready[0];s.phase='진입 조건 확인';s.reason=`${ready[0].entryReason} · ${ready[0].exitReason} · 직접 재확인 필요`;return s;}
    if(ready.length>1){s.phase='양방향 신호 상충';s.reason='LONG·SHORT 동시에 확인되어 신규 진입 보류';return s;}
    s.phase=s.plan.near?'지표 확인 대기':'진입 가격 도달 대기';
    s.reason=s.plan.blockers.slice(0,3).join(' / ')||'현재가가 유효한 진입 구간 밖입니다';
    return s;
  }
  return {analyze,closed,levels,bookBuyShare};
})();
if(typeof module!=='undefined'&&module.exports)module.exports=ScalpEngine;
