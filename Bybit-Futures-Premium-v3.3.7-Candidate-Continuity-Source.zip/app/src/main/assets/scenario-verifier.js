'use strict';
/* Forward-only verification of the app's ORIGINAL, frozen price recommendations.
   A recommended LIMIT AREA is not a confirmed trade. Only a later confirmed signal
   may create a hypothetical next-quote fill. This never executes an exchange order.
   Quotes are NOT exchange fills. Disconnects/hidden app cannot be backfilled here.
 */
const ScenarioVerifier=(()=>{
  const STORAGE='v336-recommendation-verifier-v1',MAX=500;
  const MAX_AGE={live:35*60000,scalp:3*3600000,short:3*86400000,long:21*86400000};
  // Once a hypothetical trade starts, use a separate holding window, not the
  // old pre-entry candidate deadline. A holding window still cannot validate
  // any missing quotes from a hidden/terminated app.
  const MAX_HOLD={live:90*60000,scalp:6*3600000,short:5*86400000,long:30*86400000};
  const isSide=s=>s==='LONG'||s==='SHORT';
  const isActive=s=>['WATCH','TOUCHED','PENDING','OPEN'].includes(s);
  // PRICE_TP/PRICE_SL record only the observed path after a price touch.
  // Without a confirmed entry they are NOT winning/losing trades.
  const number=x=>x===null||x===undefined||x===''?NaN:Number(x);
  const safe=(v,d)=>Number.isFinite(number(v))?number(v):d;
  function create(storage,clock=()=>Date.now()){
    let items=[],seq=0,enabled=true,persistOK=true;
    try{const raw=JSON.parse(storage?.getItem(STORAGE)||'null');if(raw?.version===1&&Array.isArray(raw.items)){
      items=raw.items.slice(-MAX);seq=safe(raw.seq,items.length);
    }}catch(_){persistOK=false;}
    const save=()=>{try{if(!storage?.setItem){persistOK=false;return;}storage.setItem(STORAGE,JSON.stringify({version:1,seq,items}));persistOK=true;}catch(_){persistOK=false;}};
    // Without a continuous quote feed, prices crossing TP/SL while app was closed
    // are UNKNOWN, not wins, not losses.
    let resumed=false;
    for(const p of items){if(isActive(p.status)){
      p.status='UNVERIFIED';p.note='앱 종료/재시작 동안 가격 추적 불가';p.closedAt=clock();resumed=true;
    }}
    if(resumed)save();
    function expire(at){let changed=false;
      for(const p of items){if(!isActive(p.status))continue;
        const preEntry=p.status==='WATCH'||p.status==='TOUCHED';
        const pending=p.status==='PENDING';
        const deadline=preEntry?(p.validUntil||p.createdAt+MAX_AGE[p.mode]):
          pending?(p.confirmAt+(p.mode==='live'?15000:60000)):
          p.fillAt+MAX_HOLD[p.mode];
        if(at>deadline){
          p.status=preEntry?'EXPIRED':'UNVERIFIED';
          p.note=preEntry?'진입 확인 없이 추천 유효기간 종료':pending?
            '진입 신호 이후 관측 시세 부족 · 가상 체결 미검증':
            '가상 포지션 관측 기간 종료 · 결과 미검증';
          p.closedAt=at;changed=true;
        }
      }if(changed)save();return changed;
    }
    function propose(v){
      if(!enabled||!v||!isSide(v.side)||!['live','scalp','short','long'].includes(v.mode))return null;
      const symbol=String(v.symbol||'').replace(/[^A-Z0-9]/g,'');
      const entry=number(v.entry),tp=number(v.tp),sl=number(v.sl),quote=number(v.price),now=safe(v.at,clock());
      const dir=v.side==='LONG'?1:-1;
      if(!symbol||![entry,tp,sl,quote].every(n=>Number.isFinite(n)&&n>0)||!(dir*(tp-entry)>0&&dir*(entry-sl)>0)||v.viable!==true||v.stale===true)return null;
      expire(now);
      // Keep EVERY published setup immutable until its own expiry/invalidation.
      // A new completed candle can publish a new plan, but cannot retroactively
      // cancel, improve, or silently reprice an older recommendation.
      const key=p=>p.symbol===symbol&&p.mode===v.mode&&p.side===v.side;
      const active=items.filter(p=>key(p)&&isActive(p.status));
      const barTime=safe(v.barTime,0);
      const sameBar=items.slice().reverse().find(p=>key(p)&&p.barTime&&p.barTime===barTime);
      if(sameBar){
        // No extra candidate from recalculation of one completed candle.
        if(isActive(sameBar.status))confirm(sameBar,v,now);
        return sameBar;
      }
      // Equivalent recommendations across several bars are the SAME setup;
      // keep the earliest quoted price, stop, target, and timestamp.
      const equivalent=active.slice().reverse().find(p=>
        Math.abs(entry-p.entry)/p.entry<=.001 &&
        Math.abs(tp-p.tp)/p.tp<=.002 &&
        Math.abs(sl-p.sl)/p.sl<=.002);
      if(equivalent){confirm(equivalent,v,now);return equivalent;}
      // No signal is invented simply because the new bar changed the levels.
      // Older candidates remain WATCH/TOUCHED; OPEN positions keep their TP/SL.
      if(items.length>=MAX){const cut=items.findIndex(p=>!isActive(p.status));if(cut>=0)items.splice(cut,1);else return null;}
      const p={id:'S'+(++seq)+'-'+now,symbol,mode:v.mode,side:v.side,
        createdAt:now,barTime:safe(v.barTime,0),entry,tp,sl,signalPrice:quote,
        fee:Math.max(0,safe(v.fee,.0006)),slip:Math.max(0,safe(v.slip,.00025)),
        leverage:Math.max(1,Math.min(20,safe(v.leverage,10))),margin:Math.max(1,safe(v.margin,100)),
        evidence:String(v.evidence||'차트 분석').slice(0,200),status:'WATCH',touchAt:null,confirmAt:null,
        fillAt:null,fill:null,closedAt:null,exit:null,netPnl:null,netRoi:null,
        lastQuoteAt:now,referencePrice:quote,validUntil:now+MAX_AGE[v.mode],
        earlierThan:null,laterRecommendationId:null,pricePathAt:null,
        note:'추천 가격 도달 및 진입 신호 확인 대기'};
      const older=active.at(-1);
      if(older){
        older.laterRecommendationId=p.id;
        if(older.status==='WATCH'||older.status==='TOUCHED')
          older.note=older.status==='WATCH'?'후속 추천 등록 · 최초 진입가 관측 계속':'후속 추천과 무관하게 최초 가격 도달 후 경로 관측 중';
      }
      items.push(p);confirm(p,v,now);save();return p;
    }
    function confirm(p,v,at){
      if(!isActive(p.status)||p.status==='PENDING'||p.status==='OPEN')return;
      const entry=number(v.entry),tp=number(v.tp),sl=number(v.sl),quote=number(v.price);
      // Never substitute newer targets for the original logged trade plan.
      const match=Math.abs(entry-p.entry)/p.entry<=.0008&&Math.abs(tp-p.tp)/p.tp<=.001&&Math.abs(sl-p.sl)/p.sl<=.001;
      const near=Number.isFinite(quote)&&Math.abs(quote-p.entry)/p.entry<=.001;
      if(!near||!match||v.verdict!==p.side||v.confirmed!==true)return;
      p.status='PENDING';p.confirmAt=at;p.lastQuoteAt=at;p.note='진입 조건 확인 · 다음 관측 시세로 가상 체결 검증 대기';save();
    }
    function onQuote(symbol,price,at=clock()){
      if(!enabled)return 0;
      at=number(at);price=number(price);symbol=String(symbol||'').replace(/[^A-Z0-9]/g,'');
      if(!symbol||![price,at].every(Number.isFinite)||price<=0)return 0;
      // Expiration must be applied BEFORE this quote is evaluated. Otherwise a
      // quote arriving after expiry could falsely be counted as a TP/SL.
      let changed=expire(at)?1:0;
      for(const p of items){if(p.symbol!==symbol||!isActive(p.status))continue;
        if(at<=p.lastQuoteAt)continue;
        const maxGap=p.mode==='live'?20000:120000;
        if(at-p.lastQuoteAt>maxGap){p.status='UNVERIFIED';p.note='시세 관측 공백 · 가격 도달 순서 확인 불가';p.closedAt=at;changed++;continue;}
        const dir=p.side==='LONG'?1:-1;
        if(p.status==='WATCH'||p.status==='TOUCHED'){
          // TOUCH and outcome without a confirmed signal are observational only.
          // They can never contribute to the virtual trade win/loss statistics.
          if(p.status==='WATCH'){
            const crossed=(p.referencePrice-p.entry)*(price-p.entry)<=0;
            if((crossed||Math.abs(price-p.entry)/p.entry<=.001)&&!p.touchAt){
              // Jumped past stop in one quote: cannot infer a tradable path.
              if(dir*(price-p.sl)<=0){
                p.status='UNVERIFIED';p.note='관측 가격이 진입·손절선을 한 번에 통과 · 순서 미확인';p.closedAt=at;
              }else{
                p.touchAt=at;p.status='TOUCHED';p.note='과거 추천 진입가 도달 · 매매 신호는 미확인';
              }
              changed++;
            }
          }else{
            const targetHit=dir*(price-p.tp)>=0,stopHit=dir*(price-p.sl)<=0;
            if(targetHit||stopHit){
              p.status=stopHit?'PRICE_SL':'PRICE_TP';p.pricePathAt=at;p.closedAt=at;
              p.note=stopHit?'진입 신호 없이 손절선 먼저 관측 · 가상 손실 아님':'진입 신호 없이 익절선 먼저 관측 · 가상 수익 아님';
              changed++;
            }
          }
          p.referencePrice=price;p.lastQuoteAt=at;continue;
        }
        if(p.status==='PENDING'){
          if(at-p.confirmAt>(p.mode==='live'?15000:60000)){
            p.status='UNVERIFIED';p.note='신호 후 가상 체결을 확인할 새 시세 부족';p.closedAt=at;changed++;continue;
          }
          const fill=price*(1+dir*p.slip);
          if(dir*(p.tp-fill)<=0||dir*(fill-p.sl)<=0){
            p.status='UNVERIFIED';p.note='다음 관측 시세가 이미 목표·손절 범위 밖 · 체결 가정 불가';p.closedAt=at;changed++;continue;
          }
          p.status='OPEN';p.fill=fill;p.fillAt=at;p.touchAt??=p.confirmAt;p.lastQuoteAt=at;
          p.note='실제 주문 아님 · 다음 관측 시세로 가상 체결 중';changed++;continue;
        }
        if(p.status==='OPEN'){
          const tpHit=dir*(price-p.tp)>=0,slHit=dir*(price-p.sl)<=0;
          if(tpHit||slHit){
            p.status=slHit?'SL':'TP';p.closedAt=at;
            // At TP, assume target price, never a better unconfirmed exit. On stop
            // gaps use observed worse price; fees and slip on both directions.
            const base=slHit?(dir>0?Math.min(price,p.sl):Math.max(price,p.sl)):p.tp;
            p.exit=base*(1-dir*p.slip);
            const notional=p.margin*p.leverage;
            const gross=dir*(p.exit-p.fill)/p.fill;
            const feeCost=p.fee*(1+p.exit/p.fill);
            p.netPnl=(gross-feeCost)*notional;
            p.netRoi=p.netPnl/p.margin*100;
            p.note=slHit?'관측 가격이 손절선 도달 · 실제 체결 아님':'관측 가격이 익절선 도달 · 실제 체결 아님';changed++;
          }else p.lastQuoteAt=at;
        }
      }
      if(changed)save();return changed;
    }
    function interrupt(why='앱 비활성화 · 이후 경로 알 수 없음'){
      let n=0;for(const p of items)if(isActive(p.status)){p.status='UNVERIFIED';p.note=why;p.closedAt=clock();n++;}
      if(n)save();return n;
    }
    function summary(mode=null){
      const rows=items.filter(p=>!mode||p.mode===mode);
      const tp=rows.filter(p=>p.status==='TP'),sl=rows.filter(p=>p.status==='SL'),closed=[...tp,...sl];
      const pnl=closed.reduce((n,p)=>n+p.netPnl,0);
      return {total:rows.length,watch:rows.filter(p=>['WATCH','TOUCHED'].includes(p.status)).length,
        touched:rows.filter(p=>!!p.touchAt).length,open:rows.filter(p=>['PENDING','OPEN'].includes(p.status)).length,
        tp:tp.length,sl:sl.length,priceTp:rows.filter(p=>p.status==='PRICE_TP').length,
        priceSl:rows.filter(p=>p.status==='PRICE_SL').length,
        completed:closed.length,winRate:closed.length?tp.length/closed.length:null,
        pnl,average:closed.length?pnl/closed.length:null,
        expired:rows.filter(p=>p.status==='EXPIRED').length,
        unknown:rows.filter(p=>['UNVERIFIED','EXPIRED','SUPERSEDED'].includes(p.status)).length,rows:rows.slice().reverse(),persistOK};
    }
    function getAll(){return JSON.parse(JSON.stringify(items));}
    function clear(){items=[];seq=0;save();}
    function exportText(){return JSON.stringify({at:new Date(clock()).toISOString(),disclaimer:'Observed next-tick scenario simulation, not actual exchange executions or a historic backtest.',items:getAll()},null,2);}
    return {propose,onQuote,interrupt,summary,getAll,clear,exportText,expire};
  }
  return {create};
})();
if(typeof module!=='undefined'&&module.exports)module.exports=ScenarioVerifier;
