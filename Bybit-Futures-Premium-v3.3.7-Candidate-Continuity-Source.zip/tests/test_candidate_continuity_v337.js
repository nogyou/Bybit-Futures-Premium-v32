'use strict';
const assert=require('node:assert/strict');
const Verifier=require('../app/src/main/assets/scenario-verifier.js');
let t=1_700_100_000_000;
const data=new Map();
const storage={getItem:k=>data.get(k)||null,setItem:(k,v)=>data.set(k,v)};
const v=Verifier.create(storage,()=>t);
const base=(opts={})=>({symbol:'BTCUSDT',mode:'live',side:'LONG',entry:100,tp:102,sl:99,
  price:103,at:t,barTime:100_000,viable:true,stale:false,verdict:'WAIT',confirmed:false,
  evidence:'과거 지지와 EMA 겹침',...opts});
const old=v.propose(base());
assert.equal(old.status,'WATCH');
// Same completed bar revised on a fast quote must not secretly rewrite candidate.
t+=1000;
assert.equal(v.propose(base({barTime:100_000,entry:101,tp:104,sl:100,price:103})).id,old.id);
assert.equal(v.getAll()[0].entry,100);
// NEW completed bar proposes an independent setup rather than terminating old.
t+=1000;
const newer=v.propose(base({barTime:160_000,entry:110,tp:114,sl:109,price:103}));
assert.notEqual(old.id,newer.id);
assert.equal(v.summary().total,2);
assert.equal(v.getAll().find(x=>x.id===old.id).status,'WATCH');
assert.equal(v.getAll().find(x=>x.id===old.id).tp,102);
assert.equal(v.getAll().find(x=>x.id===old.id).laterRecommendationId,newer.id);
// Continue observing original quote path even after newer price plan exists.
t+=1000;v.onQuote('BTCUSDT',100,t);
assert.equal(v.getAll().find(x=>x.id===old.id).status,'TOUCHED');
assert.equal(v.getAll().find(x=>x.id===newer.id).status,'WATCH');
// A price-only path is not counted as a filled trade or a winning signal.
t+=1000;v.onQuote('BTCUSDT',102.2,t);
assert.equal(v.getAll().find(x=>x.id===old.id).status,'PRICE_TP');
assert.equal(v.summary().priceTp,1);
assert.equal(v.summary().tp,0);
assert.equal(v.summary().completed,0);
assert.equal(v.getAll().find(x=>x.id===old.id).netPnl,null);
// Newly published trade after a confirmed signal still tracks its original TP/SL
// even when a different plan is published next candle.
t+=1000;
const confirmed=v.propose(base({barTime:220_000,entry:102.2,tp:106,sl:101,price:102.2,verdict:'LONG',confirmed:true}));
assert.equal(confirmed.status,'PENDING');
t+=1000;v.onQuote('BTCUSDT',102.3,t);
assert.equal(v.getAll().find(x=>x.id===confirmed.id).status,'OPEN');
t+=1000;
const other=v.propose(base({barTime:280_000,entry:120,tp:125,sl:118,price:102.3}));
assert.notEqual(confirmed.id,other.id);
assert.equal(v.getAll().find(x=>x.id===confirmed.id).status,'OPEN');
t+=1000;v.onQuote('BTCUSDT',106.4,t);
assert.equal(v.getAll().find(x=>x.id===confirmed.id).status,'TP');
assert.equal(v.summary().tp,1);
assert.equal(v.summary().completed,1);
// An expired plan must not become a winning recommendation on a later quote.
t+=1000;
const timed=v.propose(base({symbol:'ETHUSDT',barTime:400_000,entry:80,tp:85,sl:78,price:83}));
assert.equal(timed.status,'WATCH');
t+=35*60*1000+1;
v.onQuote('ETHUSDT',85,t);
assert.equal(v.getAll().find(x=>x.id===timed.id).status,'EXPIRED');
assert.equal(v.getAll().find(x=>x.id===timed.id).touchAt,null);
// Same source plan across multiple bars should not flood duplicate records.
v.clear();t+=100;
const stable=v.propose(base({barTime:500_000}));
t+=100;
assert.equal(v.propose(base({barTime:560_000})).id,stable.id);
assert.equal(v.summary().total,1);
// Observed price hitting a stop without any confirmed signal is not a trading loss.
t+=100;v.onQuote('BTCUSDT',100,t);
t+=100;v.onQuote('BTCUSDT',98.8,t);
assert.equal(v.summary().priceSl,1);assert.equal(v.summary().sl,0);
// Records persist with immutable prices and independent statuses.
const reloaded=Verifier.create(storage,()=>t+1);
assert.equal(reloaded.getAll()[0].entry,100);
assert.equal(reloaded.getAll()[0].status,'PRICE_SL');
console.log('PASS v3.3.7: independent bar plans, old quote-path tracking, real signal separation, expire-before-quote, stable price, persistence');
