'use strict';
const assert=require('assert');global.TradeEngine=require('../app/src/main/assets/engine.js');
const Scalp=require('../app/src/main/assets/scalp-engine.js');
const now=Date.UTC(2026,10,25,9,0,0);
function candles(minutes,n=240,fn=null){
  const out=[];
  for(let i=0;i<n;i++){
    const p=fn?fn(i):100+(i-n)*.025+Math.sin(i*.4)*.22;
    out.push({t:now-(n-i)*minutes*60000,o:p-.05,h:p+.35,l:p-.35,c:p,v:100+(i%11)*5});
  }
  // Last candle is in progress; it must NEVER be used as future information.
  out.push({t:now,o:5,h:10000,l:1,c:10000,v:99999});
  return out;
}
const a1=candles(1),a3=candles(3),a5=candles(5);
assert.strictEqual(Scalp.closed(a1,1,now).length,240,'unfinished bar excluded');
assert.notStrictEqual(Scalp.closed(a1,1,now).at(-1).c,10000);
const opts={candles1:a1,candles3:a3,candles5:a5,now,price:99.8,quoteTime:now,feeSide:.0006,slipSide:.00025,leverage:10,margin:100,lossBudget:100,higher15:{trend:'LONG'}};
let x=Scalp.analyze({...opts,quoteTime:now-30000});
assert.strictEqual(x.verdict,'WAIT');assert.strictEqual(x.phase,'시세 지연');
x=Scalp.analyze({...opts,candles1:a1.slice(-30)});assert.strictEqual(x.phase,'시간봉 부족');
x=Scalp.analyze(opts);assert(['WAIT','LONG','SHORT'].includes(x.verdict));
assert(x.plans.every(p=>p.side==='LONG'||p.side==='SHORT'));
assert(x.plans.every(p=>p.side==='LONG'?p.stop<p.entry&&p.tp>p.entry:p.stop>p.entry&&p.tp<p.entry));
assert(x.plans.every(p=>p.quality===false||(p.rr>=1.5&&p.grossProfitPct>=3*.17-1e-6)));
assert(!x.plan||x.plan.quality&&x.plan.riskOk,'unqualified plan must not be advertised');
assert(x.verdict==='WAIT'||x.plan.ready,'never print entry action without all checks');
const highCost=Scalp.analyze({...opts,feeSide:.009,slipSide:.005});
assert.strictEqual(highCost.verdict,'WAIT','huge costs cannot force a trade');
const missingHigher=Scalp.analyze({...opts,higher15:null});
assert.strictEqual(missingHigher.verdict,'WAIT','higher time frame missing must block entry');
const late=Scalp.analyze({...opts,now:now+20*60000,quoteTime:now+20*60000});
assert.strictEqual(late.verdict,'WAIT');assert.strictEqual(late.phase,'시간봉 지연');
// Deterministic high-volatility synthetic scenario: signal path must not be unreachable.
const z=38, raw=[]; let base=60000;
for(let i=0;i<1200;i++){
  const drift=.04+(i%200<160?.22:0);
  const noise=Math.sin(i*.23+z)*18*8+Math.sin(i*.67+z*3)*11*8;
  const open=base,close=base+drift+Math.sin(i*.39+z)*6*8;
  raw.push({t:now-(1200-i)*60000,o:open,c:close,
    h:Math.max(open,close)+Math.abs(noise)*.9+20,
    l:Math.min(open,close)-Math.abs(noise)*.9-20,
    v:100+Math.abs(Math.sin(i*.1+z)*70)});
  base=close;
}
const agg=minutes=>{const out=[];for(let i=0;i<raw.length;i+=minutes){const part=raw.slice(i,i+minutes);out.push({t:part[0].t,o:part[0].o,c:part.at(-1).c,h:Math.max(...part.map(x=>x.h)),l:Math.min(...part.map(x=>x.l)),v:part.reduce((sum,x)=>sum+x.v,0)});}return out.slice(-240);};
const synthetic={candles1:agg(1),candles3:agg(3),candles5:agg(5),now,quoteTime:now,feeSide:.0006,slipSide:.00025,leverage:10,margin:100,lossBudget:100,higher15:{trend:'LONG'}};
const offered=Scalp.analyze({...synthetic,price:raw.at(-1).c});
assert(offered.plan&&offered.plan.quality,'strong synthetic structural move can produce qualified candidate');
const triggered=Scalp.analyze({...synthetic,price:offered.plan.entry});
assert.strictEqual(triggered.verdict,'LONG','confirmed synthetic trend at entry can trigger LONG, not endless WAIT');
assert(triggered.plan.netProfitPct>0&&triggered.plan.rr>=1.5);
console.log('v3.3.4 synthetic positive signal path also passed');
console.log('v3.3.4 real-time scalping checks passed; inspected candidate plans:',x.plans.length);
