'use strict';
const assert=require('node:assert/strict');
// Browser-only TradeChart is tested separately in UI smoke. SMA must use only
// preceding/current closed bars, not a future candle.
const sma=(values,p)=>{let total=0;return values.map((v,i)=>{total+=v;if(i>=p)total-=values[i-p];return i>=p-1?total/p:NaN;});};
const x=sma([1,2,3,4,5,6],5);assert.ok(Number.isNaN(x[3]));assert.equal(x[4],3);assert.equal(x[5],4);
console.log('PASS SMA 5/10/20/60/120 forward-only calculation sanity');
