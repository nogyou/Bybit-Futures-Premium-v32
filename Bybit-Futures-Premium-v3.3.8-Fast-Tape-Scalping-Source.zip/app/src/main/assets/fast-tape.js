'use strict';
/* Selected-symbol public-trade + depth-50 orderbook reader and observed microstructure.
   Uses NO private keys / orders. Aggressor side is a proxy, not proof of the next move.
   Time-bucket extrema include movements hidden inside one-minute candles. */
const FastTape = (() => {
  const valid = x => Number.isFinite(Number(x));
  const clamp = (x,a,b) => Math.max(a,Math.min(b,x));
  function create(clock=()=>Date.now()){
    let symbol='',seconds=new Map(),seen=new Map(),lastTradeAt=0,lastTradePrice=NaN,lastBookAt=0,bids=new Map(),asks=new Map(),readyBook=false;
    function reset(sym=''){symbol=String(sym);seconds.clear();seen.clear();lastTradeAt=0;lastTradePrice=NaN;lastBookAt=0;bids.clear();asks.clear();readyBook=false;}
    function trim(at){const min=Math.floor((at-200000)/1000);for(const k of seconds.keys())if(k<min)seconds.delete(k);for(const [k,t] of seen)if(t<at-90000)seen.delete(k);}
    function addTrades(list,at=clock()){
      if(!Array.isArray(list))return 0;let accepted=0;
      for(const t of list){
        if(t?.s!==symbol)continue;
        const ts=Number(t.T),p=Number(t.p),q=Number(t.v),side=t.S;
        if(![ts,p,q].every(Number.isFinite)||p<=0||q<=0||!['Buy','Sell'].includes(side)||Math.abs(at-ts)>6000)continue;
        if(t.i&&seen.has(t.i))continue;
        if(t.i)seen.set(t.i,at);
        const k=Math.floor(ts/1000);let b=seconds.get(k);
        if(!b){b={t:k*1000,open:p,high:p,low:p,close:p,firstTs:ts,lastTs:ts,qty:0,buy:0,notional:0,count:0};seconds.set(k,b);}
        if(ts<b.firstTs){b.firstTs=ts;b.open=p;}if(ts>=b.lastTs){b.lastTs=ts;b.close=p;}
        b.high=Math.max(b.high,p);b.low=Math.min(b.low,p);b.qty+=q;b.notional+=p*q;b.buy+=side==='Buy'?q:0;b.count++;
        if(ts>=lastTradeAt){lastTradeAt=ts;lastTradePrice=p;}accepted++;
      }
      trim(at);return accepted;
    }
    function onBook(msg,at=clock()){
      const d=msg?.data;if(!d||d.s!==symbol||!Array.isArray(d.b)||!Array.isArray(d.a))return false;
      const snapshot=msg.type==='snapshot'||Number(d.u)===1;
      if(!snapshot&&!readyBook)return false;
      if(snapshot){bids.clear();asks.clear();readyBook=true;}
      for(const [arr,dst] of [[d.b,bids],[d.a,asks]])for(const level of arr){const px=Number(level[0]),qty=Number(level[1]);if(!Number.isFinite(px)||px<=0||!Number.isFinite(qty)||qty<0)continue;if(qty===0)dst.delete(px);else dst.set(px,qty);}
      lastBookAt=at;return true;
    }
    function bookSnapshot(at=clock()){
      if(!readyBook||at-lastBookAt>7000||at<lastBookAt-2000)return null;
      const b=[...bids].sort((a,c)=>c[0]-a[0]).slice(0,20),a=[...asks].sort((a,c)=>a[0]-c[0]).slice(0,20);
      if(!b.length||!a.length||b[0][0]>=a[0][0])return null;
      const money=x=>x.reduce((s,v)=>s+v[0]*v[1],0),bv=money(b),av=money(a),mid=(b[0][0]+a[0][0])/2;
      return {b,a,bid:b[0][0],ask:a[0][0],spreadPct:(a[0][0]-b[0][0])/mid*100,buyShare:bv+av>0?bv/(bv+av):null,at:lastBookAt};
    }
    function summary(at=clock()){
      const rows=[...seconds.values()].filter(b=>b.t>=at-180000&&b.t<=at+1000).sort((a,b)=>a.t-b.t);
      const window=ms=>{
        const a=rows.filter(b=>b.t+1000>at-ms);if(!a.length)return null;
        let high=-Infinity,low=Infinity,qty=0,buy=0,count=0,notional=0;
        for(const b of a){high=Math.max(high,b.high);low=Math.min(low,b.low);qty+=b.qty;buy+=b.buy;count+=b.count;notional+=b.notional;}
        const open=a[0].open,close=a.at(-1).close;
        return {high,low,open,close,rangePct:(high-low)/open*100,movePct:(close/open-1)*100,qty,buyShare:qty>0?buy/qty:null,count,vwap:qty>0?notional/qty:null};
      };
      const w10=window(10000),w30=window(30000),w60=window(60000),w180=window(180000),book=bookSnapshot(at);
      if(w180&&rows.length)w180.spanSec=(rows.at(-1).t-rows[0].t)/1000;
      const fresh=lastTradeAt>0&&at-lastTradeAt<3500&&book!==null;
      let regime='자료 수신 중';
      if(w60?.count>=12&&w60.rangePct>=0.35){
        if(w10?.movePct>=0.12&&w30?.movePct>=0.25)regime='급상승 · 변동성 확대';
        else if(w10?.movePct<=-0.12&&w30?.movePct<=-0.25)regime='급하락 · 변동성 확대';
        else regime='급변동 · 왕복 흔들림';
      } else if(w60?.count>=12) regime='보통 변동성';
      return {symbol,at,fresh,lastTradeAt,lastTradePrice,lastBookAt,book,w10,w30,w60,w180,regime};
    }
    return {reset,addTrades,onBook,bookSnapshot,summary};
  }
  class Client {
    constructor(onTrades,onBook,onStatus){this.onTrades=onTrades;this.onBook=onBook;this.onStatus=onStatus;this.symbol='';this.ws=null;this.active=false;this.retry=0;this.timer=null;this.ping=null;this.seq=0;}
    start(sym){this.stop();if(!/^[A-Z0-9]+USDT$/.test(sym))return;this.symbol=sym;this.active=true;this.retry=0;this.open(++this.seq);}
    open(id){if(!this.active||id!==this.seq)return;let ws;try{ws=new WebSocket('wss://stream.bybit.com/v5/public/linear');}catch(_){this.schedule(id);return;}this.ws=ws;
      ws.onopen=()=>{if(!this.active||this.seq!==id){ws.close();return;}this.retry=0;ws.send(JSON.stringify({op:'subscribe',args:['publicTrade.'+this.symbol,'orderbook.50.'+this.symbol]}));this.ping=setInterval(()=>{if(ws.readyState===WebSocket.OPEN)ws.send(JSON.stringify({op:'ping'}));},20000);this.onStatus?.('connected');};
      ws.onmessage=e=>{if(!this.active||this.seq!==id)return;let msg;try{msg=JSON.parse(e.data);}catch(_){return;}
        if(msg.topic==='publicTrade.'+this.symbol)this.onTrades?.(msg.data,Number(msg.ts)||Date.now());
        else if(msg.topic==='orderbook.50.'+this.symbol)this.onBook?.(msg,Number(msg.ts)||Date.now());};
      ws.onclose=()=>{clearInterval(this.ping);if(this.active&&id===this.seq){this.onStatus?.('reconnecting');this.schedule(id);}};
      ws.onerror=()=>this.onStatus?.('degraded');
    }
    schedule(id){if(!this.active||id!==this.seq)return;this.retry++;this.timer=setTimeout(()=>this.open(id),Math.min(30000,1200*Math.pow(1.6,this.retry)));}
    stop(){this.active=false;this.seq++;clearInterval(this.ping);clearTimeout(this.timer);const ws=this.ws;this.ws=null;if(ws&&(ws.readyState===0||ws.readyState===1))try{ws.close(1000,'pause');}catch(_){}}
  }
  return {create,Client};
})();
if(typeof module!=='undefined'&&module.exports)module.exports=FastTape;
