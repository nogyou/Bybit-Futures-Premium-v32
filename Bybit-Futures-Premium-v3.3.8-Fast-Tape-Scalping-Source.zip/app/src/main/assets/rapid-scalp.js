'use strict';
/* Fast-impulse candidate evaluator. Does NOT invent future TP: it needs a
   previously OBSERVED swing on the other side of entry. No actual orders. */
const RapidScalp=(()=>{
  const isNum=x=>Number.isFinite(x);
  function analyze(v){
    const now=Number(v?.now||Date.now()),price=Number(v?.price),micro=v?.micro,context=v?.context||{};
    const wait=(phase,reason)=>({verdict:'WAIT',phase,reason,plan:null,kind:'rapid'});
    if(!micro?.fresh||!micro.book||!micro.w10||!micro.w30||!micro.w60||!micro.w180)return wait('초단위 체결 확인 중','실시간 체결·호가 자료가 충분하지 않습니다');
    if(micro.w10.count<5||micro.w30.count<15||micro.w60.count<30||micro.w180.spanSec<45)return wait('체결 표본 부족','짧은 구간의 실거래 체결 표본이 부족합니다');
    if(!isNum(price)||price<=0||Math.abs(price-micro.lastTradePrice)/price>.004)return wait('시세 불일치','현재가와 체결가 차이가 커 신규 진입을 보류합니다');
    if(micro.book.spreadPct>.16)return wait('스프레드 위험','호가 스프레드 '+micro.book.spreadPct.toFixed(3)+'% · 체결비용 위험');
    if(micro.w60.rangePct<.38)return wait('급변동 조건 미충족','최근 60초 변동폭이 낮아 기존 완성봉 분석 우선');
    // Use a move back from a recent REAL extreme, not a prediction of a new high/low.
    const side=micro.w10.movePct>.10&&micro.w30.movePct>.12&&micro.w30.buyShare>.58&&micro.book.buyShare>.53?'LONG':
      micro.w10.movePct<-.10&&micro.w30.movePct<-.12&&micro.w30.buyShare<.42&&micro.book.buyShare<.47?'SHORT':null;
    if(!side)return wait('급변동 감시 중','체결 강도·가격 방향·호가 우위가 동시에 확인되지 않았습니다');
    // No impulse-only entry without existing completed-candle context.
    if(!['LONG','SHORT','RANGE'].includes(context.trend5)||![context.ema9,context.ema20].every(Number.isFinite))return wait('완성봉 근거 부족','1·3·5분봉 이동평균선 분석이 완료되지 않았습니다');
    const emaDir=context.ema9>context.ema20?'LONG':context.ema9<context.ema20?'SHORT':'RANGE';
    if(emaDir!==side)return wait('EMA 방향 미확인','1분 EMA9·20 방향과 실시간 체결 흐름이 일치하지 않습니다');
    // Do not countertrade established 5-minute direction unless structural flip is confirmed.
    if(context.trend5&&context.trend5!=='RANGE'&&context.trend5!==side)return wait('상위 추세 상충','5분봉 방향과 초단기 체결 방향이 반대라 신규 진입을 보류합니다');
    const tf=v.higher15?.trend;
    if(!tf)return wait('15분 추세 미수신','상위 시간봉 확인 정보가 없습니다');
    if(tf!==side&&tf!=='WAIT'&&tf!=='RANGE')return wait('15분 방향 상충','15분 추세 반대 방향의 빠른 진입을 보류합니다');
    const dir=side==='LONG'?1:-1, tick=Number(v.tickSize)||0;
    const snap=(x)=>tick>0?Math.round(x/tick)*tick:x;
    // Actual historical 3m traded high/low and 60s high/low; no ATR-based fictitious TP.
    const resistance=micro.w180.high,support=micro.w180.low;
    const target=snap(side==='LONG'?resistance:support);
    const cushion=price*clamp(micro.w60.rangePct*.08/100,.00008,.00045);
    const stop=snap(side==='LONG'?micro.w60.low-cushion:micro.w60.high+cushion);
    const entry=snap(price),risk=dir*(entry-stop),gross=dir*(target-entry)/entry;
    const fee=Number(v.feeSide??.0006),slip=Number(v.slipSide??.00025),cost=2*(Math.max(0,fee)+Math.max(0,slip));
    const net=gross-cost,loss=risk/entry+cost,ratio=loss>0?net/loss:NaN;
    if(!(risk>0&&gross>cost*3&&net>0&&ratio>=1.5&&target>0&&stop>0&&entry>0))return wait('급변동 손익비 부족','최근 체결 고저점으로 계산한 익절·손절이 거래비용 대비 불리합니다');
    // Don't confuse a broad 60s move with a marketable pullback.
    const overextended=(side==='LONG'?(entry-micro.w60.low):(micro.w60.high-entry))/entry*100;
    if(overextended>micro.w60.rangePct*.65)return wait('추격 매매 위험','급등·급락 이후 이미 변동폭 상당 부분을 이동했습니다');
    const leverage=Number(v.leverage)||10,margin=Number(v.margin)||100;
    const lossUsdt=margin*leverage*loss;
    if(leverage>20||lossUsdt>Number(v.lossBudget??10))return wait('위험 한도 초과','선택 레버리지와 손절 예상 손실이 허용 범위를 초과했습니다');
    return {verdict:side,kind:'rapid',phase:'초단위 체결 추세 확인',reason:`최근 10초 ${micro.w10.movePct>=0?'+':''}${micro.w10.movePct.toFixed(2)}% · 체결 ${micro.w30.count}건 · 60초 폭 ${micro.w60.rangePct.toFixed(2)}% · 실제 3분 고저점을 익절 후보로 사용`,
      plan:{side,entry,tp:target,stop,rr:ratio,quality:true,riskOk:true,ready:true,near:true,profitUsdt:margin*leverage*net,lossUsdt,netProfitPct:net*100,netLossPct:loss*100,grossProfitPct:gross*100,entryReason:'실시간 체결 압력·호가·5분봉 추세',exitReason:'최근 실제 체결 3분 고저점',blockers:[]}};
  }
  function clamp(x,a,b){return Math.max(a,Math.min(b,x));}
  return {analyze};
})();
if(typeof module!=='undefined'&&module.exports)module.exports=RapidScalp;
