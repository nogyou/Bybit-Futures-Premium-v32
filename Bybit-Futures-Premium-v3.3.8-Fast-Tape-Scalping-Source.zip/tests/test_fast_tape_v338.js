'use strict';
const assert=require('node:assert/strict');
const FastTape=require('../app/src/main/assets/fast-tape.js');
const Rapid=require('../app/src/main/assets/rapid-scalp.js');
const now=1764067200000;const tape=FastTape.create(()=>now);tape.reset('VOLUSDT');
// Bybit orderbook deltas alone are invalid without an initial snapshot.
assert.equal(tape.onBook({type:'delta',data:{s:'VOLUSDT',b:[['99.9','80']],a:[['100.1','60']]}},now),false);
assert.equal(tape.bookSnapshot(now),null);
assert(tape.onBook({type:'snapshot',data:{s:'VOLUSDT',b:[['99.90','100'],['99.80','90']],a:[['100.10','70'],['100.20','90']]}},now));
assert(tape.onBook({type:'delta',data:{s:'VOLUSDT',b:[['99.90','0'],['99.95','140']],a:[['100.10','40']]}},now));
assert.equal(tape.bookSnapshot(now).bid,99.95);
assert.equal(tape.bookSnapshot(now).ask,100.10);
const trades=[];
for(let i=0;i<155;i++){
  const t=now-(155-i)*1000;
  let p=100;
  if(i===125)p=98.6; // a deep intra-minute wick must be preserved
  else if(i===60)p=102.6;
  else if(i>130)p=99.30+(i-130)*.035;
  else p=99.65+(i%11)*.013;
  trades.push({s:'VOLUSDT',T:t,p:String(p),v:'10',S:i%5===0?'Sell':'Buy',i:'T'+i});
}
for(const tr of trades)assert.equal(tape.addTrades([tr],tr.T+30),1);
assert.equal(tape.addTrades(trades,now),0,'duplicated publicTrade IDs must not inflate volume');
const t=tape.summary(now);
assert(t.fresh);
assert(t.w180.rangePct>3.5,'intra-minute high/low and reversals should be preserved');
assert(t.w60.low<=98.6,'low of intra-minute trade is not lost');
assert(t.w60.count>=55);
assert(t.w30.buyShare>.70);
assert(t.w180.spanSec>=140);
assert.equal(tape.summary(now+10000).fresh,false,'stale feed cannot give entry signal');
assert.equal(tape.bookSnapshot(now+10000),null,'stale orderbook cannot be used');
tape.reset('BTCUSDT');assert.equal(tape.summary(now).w60,null);
// Full-cost, both-side, context and book gates for a real short-burst LONG.
const micro={fresh:true,lastTradePrice:100,book:{spreadPct:.03,buyShare:.64},w10:{count:12,movePct:.17},w30:{count:30,movePct:.30,buyShare:.71},
 w60:{count:60,rangePct:.83,high:100.60,low:99.80},w180:{high:102,low:98.6,spanSec:100}};
const input={micro,now,price:100,context:{trend5:'LONG',ema9:101,ema20:100},higher15:{trend:'LONG'},feeSide:.0006,slipSide:.00025,margin:100,leverage:5,lossBudget:30,tickSize:.01};
const good=Rapid.analyze(input);assert.equal(good.verdict,'LONG',JSON.stringify(good));
assert(good.plan.rr>=1.5 && good.plan.tp===102 && good.plan.stop<100);
assert.equal(Rapid.analyze({...input,context:{trend5:'SHORT',ema9:99,ema20:100}}).verdict,'WAIT','higher-timeframe conflict');
assert.equal(Rapid.analyze({...input,micro:{...micro,book:{...micro.book,spreadPct:.4}}}).verdict,'WAIT','spread veto');
assert.equal(Rapid.analyze({...input,feeSide:.01,slipSide:.005}).verdict,'WAIT','cost veto');
assert.equal(Rapid.analyze({...input,lossBudget:0.1}).verdict,'WAIT','risk veto');
assert.equal(Rapid.analyze({...input,micro:{...micro,fresh:false}}).verdict,'WAIT','stale veto');
const short={...micro,lastTradePrice:100,book:{spreadPct:.04,buyShare:.37},w10:{count:12,movePct:-.19},w30:{count:30,movePct:-.28,buyShare:.3},
 w60:{count:65,rangePct:.84,high:100.20,low:99.36},w180:{high:102,low:98.7,spanSec:100}};
const goodShort=Rapid.analyze({...input,micro:short,context:{trend5:'SHORT',ema9:99,ema20:100},higher15:{trend:'SHORT'}});
assert.equal(goodShort.verdict,'SHORT',JSON.stringify(goodShort));
assert(goodShort.plan.tp<goodShort.plan.entry&&goodShort.plan.stop>goodShort.plan.entry);
console.log('PASS v3.3.8 fast tape: 1s bucket spikes, orderbook delta, duplicate/stale checks, LONG+SHORT, cost/stop/trend risk gates');
