"""v3.3.7 browser UI smoke, mocked exchange data and mocked preexisting journal; NOT real trading performance."""
import asyncio,json,math,re,time
from pathlib import Path
from playwright.async_api import async_playwright
ROOT=Path(__file__).resolve().parents[1]/'app/src/main/assets'
OUT=Path(__file__).resolve().parents[1]/'tests'
now=int(time.time()*1000)
def candles(interval):
    ms={'1':60000,'3':180000,'5':300000,'15':900000,'30':1800000,'60':3600000,'240':14400000,'D':86400000,'W':604800000}[interval]
    start=now//ms*ms
    out=[]
    for i in range(240):
        v=60000+(i-240)*5+math.sin(i*.4)*60
        o=v-13;c=v+14;h=max(o,c)+44;l=min(o,c)-52
        out.append([str(start-(240-i)*ms),str(o),str(h),str(l),str(c),str(200+i%16*8),str(18000)])
    out.append([str(start),'60000','60040','59950','60010','1000','30000'])
    return list(reversed(out))
async def main():
  async with async_playwright() as pw:
    browser=await pw.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'],headless=True)
    page=await browser.new_page(viewport={'width':1420,'height':810},device_scale_factor=1)
    errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
    raw=(ROOT/'index.html').read_text()
    await page.set_content(re.sub(r'<script[^>]+></script>|<link[^>]+stylesheet[^>]*>','',raw),wait_until='load')
    await page.add_style_tag(content=(ROOT/'style.css').read_text())
    await page.evaluate("""() => { const memory={}; Object.defineProperty(window,'localStorage',{configurable:true,value:{getItem:k=>memory[k]??null,setItem:(k,v)=>memory[k]=String(v)}}); }""")
    test_rows=[]
    for n,(status,mode,side,price,tp,sl,pnl) in enumerate([
      ('WATCH','live','LONG',60000,60200,59900,None),('WATCH','live','LONG',60100,60400,60000,None),('PRICE_TP','scalp','SHORT',61000,60700,61150,None),('PRICE_SL','short','LONG',59500,60500,59100,None),('TP','live','LONG',60000,60200,59900,1.5),('SL','scalp','SHORT',61000,60700,61150,-2),('EXPIRED','long','SHORT',62000,59000,62800,None)]):
      test_rows.append(dict(id=f'TEST{n}',symbol='BTCUSDT',mode=mode,side=side,status=status,entry=price,tp=tp,sl=sl,
        createdAt=now-(n+2)*500000,fillAt=now-(n+1)*500000 if status in ('TP','SL') else None,
        closedAt=now-n*500000,netPnl=pnl,note='테스트 데이터 · 실제 실적 아님',touchAt=None))
    test_rows[0]['laterRecommendationId']='TEST1'
    await page.evaluate("rows=>localStorage.setItem('v336-recommendation-verifier-v1',JSON.stringify({version:1,seq:7,items:rows}))",test_rows)
    klines={tf:candles(tf) for tf in ['1','3','5','15','30','60','240','D','W']}
    ticker={'symbol':'BTCUSDT','lastPrice':'60000','price24hPcnt':'0.012','highPrice24h':'61300','lowPrice24h':'59000','turnover24h':'1430000000','fundingRate':'0.0001'}
    await page.evaluate("""({ticker,klines}) => { window.fetch=async url=>{ const u=new URL(url);const api=u.pathname.split('/').pop();const res=api==='tickers'?{list:[ticker]}:api==='instruments-info'?{list:[{symbol:'BTCUSDT',quoteCoin:'USDT',status:'Trading',contractType:'LinearPerpetual',priceFilter:{tickSize:'0.1'},leverageFilter:{maxLeverage:'20'}}],nextPageCursor:''}:api==='kline'?{list:klines[u.searchParams.get('interval')]}:api==='orderbook'?{b:[['59995','30'],['59990','20']],a:[['60005','15'],['60010','20']]}:api==='open-interest'?{list:[{timestamp:'1',openInterest:'10000'},{timestamp:'2',openInterest:'9900'}]}:{};return {ok:true,json:async()=>({retCode:0,result:res})};}; window.WebSocket=class{static OPEN=1; constructor(){this.readyState=1;setTimeout(()=>this.onopen?.(),100)} send(){} close(){this.readyState=3}}; }""",{'ticker':ticker,'klines':klines})
    for f in ['engine.js','scalp-engine.js','fast-tape.js','rapid-scalp.js','simple-plan.js','comparison.js','stream.js','chart.js','position.js','decision-lab.js','scenario-verifier.js','signal-alert.js','app.js','news.js']:
      await page.add_script_tag(content=(ROOT/f).read_text())
    await page.wait_for_function("document.querySelector('#symbolTitle').textContent==='BTCUSDT'",timeout=15000)
    assert await page.locator('#scenarioReportButton').is_visible()
    assert len(await page.locator('[data-chart-ma]').all())==5
    assert 'active' in (await page.locator('[data-chart-ma="20"]').get_attribute('class') or '')
    await page.locator('[data-chart-ma="120"]').click()
    assert 'active' in (await page.locator('[data-chart-ma="120"]').get_attribute('class') or '')
    await page.locator('[data-chart-ma="20"]').click()
    assert 'active' not in (await page.locator('[data-chart-ma="20"]').get_attribute('class') or '')
    await page.locator('#liveScalpBtn').click()
    await page.wait_for_function("document.querySelector('#scalpTime').textContent.includes('완성봉 분석 ')",timeout=15000)
    assert await page.locator('#scalpPanel').is_visible()
    # Main big banner must reflect the same verdict as live scalping panel.
    sv=await page.locator('#scalpVerdict').inner_text();big=await page.locator('#verdictText').inner_text()
    assert (('WAIT' in sv and big=='WAIT') or ('LONG' in sv and big=='LONG') or ('SHORT' in sv and big=='SHORT')),(sv,big)
    await page.evaluate("""() => {const e=document.createElement('div');e.textContent='오프라인 UI 테스트 · 가상 시세/성과 · 실제 매매 기록 아님';Object.assign(e.style,{position:'fixed',zIndex:999,left:'50%',bottom:'4px',transform:'translateX(-50%)',background:'#ad7720',color:'#06111e',padding:'5px 12px',font:'bold 11px system-ui'});document.body.append(e)}""")
    await page.screenshot(path=str(OUT/'v337-main-preview.png'))
    await page.locator('#scenarioReportButton').click()
    assert await page.locator('#verificationRows tr').count()>=7
    assert '후속 추천 있음' in await page.locator('#verificationRows').inner_text()
    assert '가격만 익절선 도달' in await page.locator('#verificationRows').inner_text()
    assert '가격만 손절선 도달' in await page.locator('#verificationRows').inner_text()
    assert '신호 없는 가격 경로' in await page.locator('#verificationKpis').inner_text()
    assert '익절선 도달' in await page.locator('#verificationRows').inner_text()
    await page.locator('#verificationMode').select_option('live')
    assert await page.locator('#verificationRows tr').count()==3
    await page.locator('#verificationMode').select_option('')
    assert '가상 누적' in await page.locator('#verificationKpis').inner_text()
    await page.screenshot(path=str(OUT/'v337-verification-preview.png'))
    await page.locator('#dialogClose').click()
    await page.set_viewport_size({'width':820,'height':1280})
    await page.wait_for_timeout(160)
    assert await page.evaluate('document.documentElement.scrollWidth <= innerWidth+2')
    await page.locator('#scenarioReportButton').click()
    await page.screenshot(path=str(OUT/'v337-verification-portrait-preview.png'),full_page=True)
    assert not errors,errors
    print('PASS v3.3.7 GUI: SMA buttons, scalp WAIT sync, verification report, filters, mobile layout, page errors none')
    await browser.close()
if __name__=='__main__':asyncio.run(main())
