"""Offline UI verification; simulated candles, not live market data."""
import asyncio, json, math, re, time
from pathlib import Path
from playwright.async_api import async_playwright
ROOT=Path(__file__).resolve().parents[1]/'app/src/main/assets'
OUT=Path(__file__).resolve().parents[1]/'tests/v334-scalping-preview.png'
now=int(time.time()*1000)
def candles(interval):
    ms={'1':60000,'3':180000,'5':300000,'15':900000,'30':1800000,'60':3600000,'240':14400000,'D':86400000,'W':604800000}[interval]
    start=now//ms*ms
    out=[]
    for i in range(240):
        v=60000+(i-240)*5+math.sin(i*.4)*60
        o=v-13; c=v+14; h=max(o,c)+44;l=min(o,c)-52
        out.append([str(start-(240-i)*ms),str(o),str(h),str(l),str(c),str(200+i%16*8),str(18000)])
    # opening current candle (must be rejected by the strategy engine)
    out.append([str(start),'60000','60040','59950','60010','1000','30000'])
    return list(reversed(out))
async def main():
  async with async_playwright() as pw:
    browser=await pw.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'],headless=True)
    page=await browser.new_page(viewport={'width':1440,'height':810},device_scale_factor=1)
    errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
    raw=(ROOT/'index.html').read_text()
    await page.set_content(re.sub(r'<script[^>]+></script>|<link[^>]+stylesheet[^>]*>','',raw),wait_until='load')
    await page.add_style_tag(content=(ROOT/'style.css').read_text())
    await page.evaluate("""() => { const memory={}; Object.defineProperty(window,'localStorage',{configurable:true,value:{getItem:k=>memory[k]??null,setItem:(k,v)=>memory[k]=String(v)}}); }""")
    klines={tf:candles(tf) for tf in ['1','3','5','15','30','60','240','D','W']}
    ticker={'symbol':'BTCUSDT','lastPrice':'60000','price24hPcnt':'0.012','highPrice24h':'61300','lowPrice24h':'59000','turnover24h':'1430000000','fundingRate':'0.0001'}
    await page.evaluate("""({ticker,klines}) => { window.fetch=async url=>{ const u=new URL(url);const api=u.pathname.split('/').pop();const res=api==='tickers'?{list:[ticker]}:api==='instruments-info'?{list:[{symbol:'BTCUSDT',quoteCoin:'USDT',status:'Trading',contractType:'LinearPerpetual',priceFilter:{tickSize:'0.1'},leverageFilter:{maxLeverage:'20'}}],nextPageCursor:''}:api==='kline'?{list:klines[u.searchParams.get('interval')]}:api==='orderbook'?{b:[['59995','30'],['59990','20']],a:[['60005','15'],['60010','20']]}:api==='open-interest'?{list:[{timestamp:'1',openInterest:'10000'},{timestamp:'2',openInterest:'9900'}]}:{};return {ok:true,json:async()=>({retCode:0,result:res})};}; window.WebSocket=class{static OPEN=1; constructor(){this.readyState=1;setTimeout(()=>this.onopen?.(),100)} send(){} close(){this.readyState=3}}; }""",{'ticker':ticker,'klines':klines})
    for f in ['engine.js','scalp-engine.js','fast-tape.js','rapid-scalp.js','simple-plan.js','comparison.js','stream.js','chart.js','position.js','decision-lab.js','scenario-verifier.js','signal-alert.js','app.js','news.js']:
      await page.add_script_tag(content=(ROOT/f).read_text())
    await page.wait_for_function("document.querySelector('#symbolTitle').textContent==='BTCUSDT'",timeout=12000)
    assert await page.locator('#simplePlanPanel').is_visible()
    await page.locator('#liveScalpBtn').click()
    await page.wait_for_function("document.querySelector('#scalpTime').textContent.includes('분석 ') && !document.querySelector('#scalpTime').textContent.includes('대기')",timeout=12000)
    assert '초단위' in await page.locator('#scalpPulse').inner_text() or '변동성' in await page.locator('#scalpPulse').inner_text() or '최근' in await page.locator('#scalpPulse').inner_text()
    assert await page.locator('#scalpPanel').is_visible()
    assert 'selected' in (await page.locator('[data-tf="1"]').get_attribute('class') or '')
    assert not await page.locator('#simplePlanPanel').is_visible()
    assert await page.locator('#scalpNow').inner_text()!='--'
    assert await page.locator('#scalpVerdict').inner_text() in ['보류 · WAIT','LONG 진입 조건 확인','SHORT 진입 조건 확인']
    assert '3·5·15분' in await page.locator('#modeContext').inner_text()
    await page.locator('.analysis-panel').evaluate('e=>e.scrollTop=0')
    label=await page.locator('#scalpVerdict').inner_text()
    await page.evaluate("""() => {const el=document.createElement('div');el.textContent='오프라인 UI 검증 · 가상 테스트 시세 · 실제 매매 추천 아님';Object.assign(el.style,{position:'fixed',zIndex:999,left:'50%',bottom:'4px',transform:'translateX(-50%)',background:'#ad7720',color:'#06111e',padding:'5px 12px',font:'bold 11px system-ui'});document.body.append(el)}""")
    await page.screenshot(path=str(OUT))
    await page.set_viewport_size({'width':810,'height':1280})
    await page.wait_for_timeout(150)
    assert await page.evaluate('document.documentElement.scrollWidth <= innerWidth+2')
    await page.screenshot(path=str(OUT.parent/'v334-scalping-portrait-preview.png'),full_page=True)
    await page.locator('[data-strategy=short]').click()
    assert not await page.locator('#scalpPanel').is_visible()
    assert await page.locator('#simplePlanPanel').is_visible()
    assert 'selected' in (await page.locator('[data-tf="15"]').get_attribute('class') or '')
    assert not errors,errors
    print('PASS v3.3.4 scalp button, data load, separate screen, hide/restore old mode, portrait; verdict:',label)
    await browser.close()
if __name__=='__main__':asyncio.run(main())
